import tkinter as tk
import math
import random


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

SIGNAL = "#1e5fff"
ENVELOPE = "#e53935"
AXIS = "#000000"
GRID = "#ececf0"
ZERO = "#c0c0c0"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class ModulationApp:
    def __init__(self, root):
        self.root = root
        root.title("Цифровые модуляции: ASK, FSK, PSK")
        root.geometry("1250x980")
        root.minsize(1150, 940)
        root.configure(bg=BG)
        root.resizable(False, False)

        # Параметры
        self.bits = [1, 0, 1, 1, 0, 0, 1, 0]
        self.fc = 15.0
        self.fs = 2.0
        self.ask_depth = 100
        self.fsk_deviation = 50

        self._build_header()
        self._build_input()
        self._build_plots()
        self._build_controls()

        self.redraw()

    # ════════════════════════════════════════════════════════════
    # ЗАГОЛОВОК
    # ════════════════════════════════════════════════════════════
    def _build_header(self):
        tk.Label(self.root, text="Цифровые виды модуляции",
                 font=("Segoe UI", 16, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(14, 3))

        tk.Label(self.root,
                 text="ASK · FSK · PSK — амплитудная, частотная, фазовая манипуляция",
                 font=("Segoe UI", 10),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

    # ════════════════════════════════════════════════════════════
    # ВВОД БИТ
    # ════════════════════════════════════════════════════════════
    def _build_input(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=24, pady=(0, 10), fill="x")

        row = tk.Frame(card, bg=CARD)
        row.pack(padx=18, pady=12, fill="x")

        tk.Label(row, text="Битовая последовательность:",
                 font=("Segoe UI", 11, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 12))

        self.entry = tk.Entry(row, font=("Consolas", 14, "bold"),
                              bg="#fafafa", fg=TEXT,
                              bd=1, relief="solid",
                              highlightthickness=1,
                              highlightbackground=BORDER,
                              highlightcolor=ACCENT,
                              width=40)
        self.entry.pack(side="left", padx=(0, 12), ipady=5)
        self.entry.insert(0, "10110010")

        self._btn(row, "🎲", ACCENT, ACCENT_HOVER,
                  self.random_bits, width=3).pack(side="left", padx=3)
        self._btn(row, "✓ Применить", GREEN, GREEN_HOVER,
                  self.apply).pack(side="left", padx=3)
        self._btn(row, "1010…", ORANGE, ORANGE_HOVER,
                  self.set_alternating).pack(side="left", padx=3)

    def random_bits(self):
        n = random.choice([8, 10, 12, 16])
        s = "".join(random.choice("01") for _ in range(n))
        self.entry.delete(0, tk.END)
        self.entry.insert(0, s)
        self.apply()

    def set_alternating(self):
        self.entry.delete(0, tk.END)
        self.entry.insert(0, "10101010")
        self.apply()

    def apply(self):
        s = "".join(c for c in self.entry.get() if c in "01")
        if not s:
            s = "10101010"
            self.entry.delete(0, tk.END)
            self.entry.insert(0, s)
        self.bits = [int(c) for c in s]
        self.redraw()

    # ════════════════════════════════════════════════════════════
    # ГРАФИКИ
    # ════════════════════════════════════════════════════════════
    def _build_plots(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=24, pady=(0, 10))

        self.canvas = tk.Canvas(card, width=1200, height=680,
                                bg="white", highlightthickness=0)
        self.canvas.pack(padx=15, pady=15)

    # ════════════════════════════════════════════════════════════
    # ПАРАМЕТРЫ
    # ════════════════════════════════════════════════════════════
    def _build_controls(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=24, pady=(0, 16), fill="x")

        row1 = tk.Frame(card, bg=CARD)
        row1.pack(fill="x", padx=16, pady=(12, 6))

        self._slider(row1, "Несущая f_c", "Гц",
                     5, 30, self.fc, 1,
                     self._set_fc, SIGNAL)

        self._slider(row1, "Манипуляция f_s", "Гц",
                     1, 10, self.fs, 0.5,
                     self._set_fs, ENVELOPE)

        row2 = tk.Frame(card, bg=CARD)
        row2.pack(fill="x", padx=16, pady=(0, 12))

        self._slider(row2, "Глубина ASK", "%",
                     0, 100, self.ask_depth, 5,
                     self._set_ask, PURPLE)

        self._slider(row2, "Девиация FSK", "%",
                     10, 100, self.fsk_deviation, 5,
                     self._set_fsk, ORANGE)

    def _slider(self, parent, label, unit, vmin, vmax, initial, step,
                callback, color):
        f = tk.Frame(parent, bg=CARD)
        f.pack(side="left", fill="x", expand=True, padx=(0, 20))

        header = tk.Frame(f, bg=CARD)
        header.pack(fill="x")

        tk.Label(header, text=label,
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED).pack(side="left")

        lbl = tk.Label(header, text=f"{initial:g} {unit}".strip(),
                       font=("Consolas", 11, "bold"),
                       bg=CARD, fg=color)
        lbl.pack(side="right")

        def on_move(v):
            val = float(v)
            callback(val)
            if unit == "%":
                lbl.config(text=f"{int(val)} %")
            elif unit == "Гц":
                lbl.config(text=f"{val:.1f} Гц")
            else:
                lbl.config(text=f"{val:g} {unit}")
            self.redraw()

        scale = tk.Scale(f, from_=vmin, to=vmax, resolution=step,
                         orient="horizontal", showvalue=False,
                         bg=CARD, fg=TEXT, troughcolor="#ececf0",
                         activebackground=color,
                         highlightthickness=0, bd=0,
                         sliderlength=18, width=8,
                         command=on_move)
        scale.set(initial)
        scale.pack(fill="x", pady=(4, 0))
        return scale

    def _set_fc(self, v): self.fc = v
    def _set_fs(self, v): self.fs = v
    def _set_ask(self, v): self.ask_depth = v
    def _set_fsk(self, v): self.fsk_deviation = v

    def _btn(self, parent, text, bg, hover, command, width=None):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="#ffffff",
                        activebackground=hover,
                        activeforeground="#ffffff",
                        bd=0, padx=14, pady=8, cursor="hand2",
                        command=command)
        if width:
            btn.config(width=width)
        return btn

    # ════════════════════════════════════════════════════════════
    # ОТРИСОВКА
    # ════════════════════════════════════════════════════════════
    def redraw(self):
        c = self.canvas
        c.delete("all")

        W = 1200
        H = 680

        # Три области по вертикали
        section_h = H // 3

        self._draw_section(c, 0 * section_h, section_h,
                           "ASK — амплитудная манипуляция",
                           "1 → есть сигнал, 0 → нет сигнала",
                           self._ask_signal)

        self._draw_section(c, 1 * section_h, section_h,
                           "FSK — частотная манипуляция",
                           "1 → высокая частота, 0 → низкая частота",
                           self._fsk_signal)

        self._draw_section(c, 2 * section_h, section_h,
                           "PSK — фазовая манипуляция (BPSK)",
                           "1 → фаза 0°, 0 → фаза 180°",
                           self._psk_signal)

    def _draw_section(self, c, y_base, section_h, title, subtitle, func):
        W = 1200
        x0, x1 = 70, W - 40
        y_top = y_base + 40
        y_bot = y_base + section_h - 30
        cy = (y_top + y_bot) / 2

        # Заголовок
        c.create_text(x0, y_base + 15,
                      text=title,
                      font=("Segoe UI", 11, "bold"),
                      fill=TEXT, anchor="w")
        c.create_text(x0 + 340, y_base + 15,
                      text=subtitle,
                      font=("Segoe UI", 9),
                      fill=MUTED, anchor="w")

        # Сетка по битам
        n = len(self.bits)
        t_max = n / self.fs

        # Вертикальные линии по границам бит
        for i in range(n + 1):
            t = i / self.fs
            px = x0 + (t / t_max) * (x1 - x0)
            c.create_line(px, y_top, px, y_bot,
                          fill=GRID, width=1)

        # Нулевая линия
        c.create_line(x0, cy, x1, cy, fill=ZERO, width=1)

        # Ось X
        c.create_line(x0 - 15, cy, x1 + 10, cy,
                      fill=AXIS, width=1,
                      arrow="last", arrowshape=(8, 10, 3))

        # Подписи бит внизу
        for i, bit in enumerate(self.bits):
            t_center = (i + 0.5) / self.fs
            px = x0 + (t_center / t_max) * (x1 - x0)
            c.create_text(px, y_bot + 12,
                          text=str(bit),
                          font=("Consolas", 10, "bold"),
                          fill=ACCENT if bit == 1 else MUTED)

        # ─── Сигнал ─────────────────────────────────────────
        points = func(x0, x1, cy, y_top, y_bot, t_max)
        c.create_line(*points, fill=SIGNAL, width=2)

    # ─── ASK ────────────────────────────────────────────────────
    def _ask_signal(self, x0, x1, cy, y_top, y_bot, t_max):
        """ASK: 1 → синус, 0 → 0."""
        n = len(self.bits)
        amplitude = (y_bot - y_top) / 2 * 0.9
        depth = self.ask_depth / 100.0

        points = []
        samples_per_bit = 80
        total = n * samples_per_bit

        for i in range(total + 1):
            t = t_max * i / total
            bit_idx = min(n - 1, int(t * self.fs))
            bit = self.bits[bit_idx]

            # Амплитуда: 1 → A, 0 → A*(1-depth)
            amp = amplitude if bit == 1 else amplitude * (1 - depth)
            y = amp * math.sin(2 * math.pi * self.fc * t)

            px = x0 + (t / t_max) * (x1 - x0)
            py = cy - y
            points.extend([px, py])

        # Огибающая
        env_pts = []
        for i in range(n + 1):
            t = i / self.fs
            bit_idx = min(n - 1, i) if i < n else n - 1
            bit = self.bits[bit_idx]
            amp = amplitude if bit == 1 else amplitude * (1 - depth)
            px = x0 + (t / t_max) * (x1 - x0)
            env_pts.extend([px, cy - amp])

        return points

    # ─── FSK ────────────────────────────────────────────────────
    def _fsk_signal(self, x0, x1, cy, y_top, y_bot, t_max):
        """FSK: 1 → f_c + dev, 0 → f_c - dev."""
        n = len(self.bits)
        amplitude = (y_bot - y_top) / 2 * 0.9
        dev_pct = self.fsk_deviation / 100.0
        f_high = self.fc * (1 + dev_pct)
        f_low = self.fc * (1 - dev_pct)

        points = []
        samples_per_bit = 100
        total = n * samples_per_bit

        # Накопленная фаза (чтобы не было разрывов)
        phase = 0.0

        for i in range(total + 1):
            t = t_max * i / total
            bit_idx = min(n - 1, int(t * self.fs))
            bit = self.bits[bit_idx]
            f = f_high if bit == 1 else f_low

            # Плавно накапливаем фазу
            dt = t_max / total
            phase += 2 * math.pi * f * dt
            y = amplitude * math.sin(phase)

            px = x0 + (t / t_max) * (x1 - x0)
            py = cy - y
            points.extend([px, py])

        return points

    # ─── PSK (BPSK) ─────────────────────────────────────────────
    def _psk_signal(self, x0, x1, cy, y_top, y_bot, t_max):
        """PSK BPSK: 1 → фаза 0, 0 → фаза π."""
        n = len(self.bits)
        amplitude = (y_bot - y_top) / 2 * 0.9

        points = []
        samples_per_bit = 100
        total = n * samples_per_bit

        for i in range(total + 1):
            t = t_max * i / total
            bit_idx = min(n - 1, int(t * self.fs))
            bit = self.bits[bit_idx]

            # Фаза 0 или π
            phase = 0 if bit == 1 else math.pi
            y = amplitude * math.sin(2 * math.pi * self.fc * t + phase)

            px = x0 + (t / t_max) * (x1 - x0)
            py = cy - y
            points.extend([px, py])

        return points


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = ModulationApp(root)
    root.mainloop()
