import tkinter as tk
import random


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
ACCENT_PRESS = "#004c99"

PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"
PURPLE_PRESS = "#6c3483"

ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
ORANGE_PRESS = "#a36606"

GREEN = "#30d158"
GREEN_HOVER = "#20a544"

RED = "#e53935"
RED_HOVER = "#cc2f26"

BIT_ON = "#30d158"
BIT_ON_HOVER = "#20a544"
BIT_OFF = "#e5e5ea"
BIT_OFF_HOVER = "#d0d0d5"
BIT_TEXT_ON = "#ffffff"
BIT_TEXT_OFF = "#8a8a8e"

HEX_COLOR = "#8e44ad"
BIN_COLOR = "#0a84ff"
DEC_COLOR = "#ff9f0a"
CRC_COLOR = "#e53935"


# ═══════════════════════════════════════════════════════════════════
# БИТ-ПЕРЕКЛЮЧАТЕЛЬ
# ═══════════════════════════════════════════════════════════════════
class BitSwitch:
    def __init__(self, parent, index, on_change):
        self.index = index
        self.value = 0
        self.on_change = on_change

        self.btn = tk.Button(
            parent, text="0",
            font=("Consolas", 13, "bold"),
            bg=BIT_OFF, fg=BIT_TEXT_OFF,
            activebackground=BIT_OFF_HOVER,
            activeforeground=BIT_TEXT_OFF,
            bd=0, relief="flat",
            width=3, height=1,
            cursor="hand2",
            command=self.toggle,
        )
        self.btn.bind("<Enter>", self._on_enter)
        self.btn.bind("<Leave>", self._on_leave)

    def _on_enter(self, e):
        self.btn.config(bg=BIT_ON_HOVER if self.value == 1 else BIT_OFF_HOVER)

    def _on_leave(self, e):
        self.btn.config(bg=BIT_ON if self.value == 1 else BIT_OFF)

    def toggle(self):
        self.value = 1 - self.value
        self._refresh()
        self.on_change()

    def set(self, value):
        self.value = value
        self._refresh()

    def _refresh(self):
        if self.value == 1:
            self.btn.config(text="1", bg=BIT_ON, fg=BIT_TEXT_ON,
                            activebackground=BIT_ON_HOVER,
                            activeforeground=BIT_TEXT_ON)
        else:
            self.btn.config(text="0", bg=BIT_OFF, fg=BIT_TEXT_OFF,
                            activebackground=BIT_OFF_HOVER,
                            activeforeground=BIT_TEXT_OFF)


# ═══════════════════════════════════════════════════════════════════
# СТРОКА БАЙТА
# ═══════════════════════════════════════════════════════════════════
class ByteRow:
    def __init__(self, parent, index, on_change):
        self.index = index
        self.on_change = on_change
        self.bits = []

        self.frame = tk.Frame(parent, bg=CARD)

        # Метка
        tk.Label(self.frame, text=f"Байт {index + 1}",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT, width=7, anchor="w"
                 ).grid(row=0, column=0, padx=(0, 10), pady=5)

        # 8 переключателей
        bits_frame = tk.Frame(self.frame, bg=CARD)
        bits_frame.grid(row=0, column=1, pady=5)
        for i in range(8):
            bit = BitSwitch(bits_frame, i, self._on_bit_change)
            bit.btn.pack(side="left", padx=2)
            self.bits.append(bit)

        # Разделитель
        tk.Frame(self.frame, bg=BORDER, width=1
                 ).grid(row=0, column=2, padx=10, sticky="ns", pady=5)

        # BIN
        bin_frame = tk.Frame(self.frame, bg=CARD)
        bin_frame.grid(row=0, column=3, padx=(0, 10), pady=5)
        tk.Label(bin_frame, text="BIN", font=("Segoe UI", 7, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w")
        self.binary_label = tk.Label(
            bin_frame, text="00000000",
            font=("Consolas", 11, "bold"),
            bg=CARD, fg=BIN_COLOR
        )
        self.binary_label.pack()

        # DEC
        dec_frame = tk.Frame(self.frame, bg=CARD)
        dec_frame.grid(row=0, column=4, padx=(0, 10), pady=5)
        tk.Label(dec_frame, text="DEC", font=("Segoe UI", 7, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w")
        self.dec_label = tk.Label(
            dec_frame, text="0",
            font=("Consolas", 11, "bold"),
            bg=CARD, fg=DEC_COLOR, width=4
        )
        self.dec_label.pack()

        # HEX
        hex_frame = tk.Frame(self.frame, bg=CARD)
        hex_frame.grid(row=0, column=5, pady=5)
        tk.Label(hex_frame, text="HEX", font=("Segoe UI", 7, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w")
        self.hex_label = tk.Label(
            hex_frame, text="0x00",
            font=("Consolas", 11, "bold"),
            bg=CARD, fg=HEX_COLOR, width=5
        )
        self.hex_label.pack()

    def _on_bit_change(self):
        self._update_labels()
        if self.on_change:
            self.on_change()

    def get_value(self):
        value = 0
        for i, bit in enumerate(self.bits):
            if bit.value == 1:
                value |= (1 << (7 - i))
        return value

    def set_value(self, value):
        value = value & 0xFF
        for i, bit in enumerate(self.bits):
            bit.set((value >> (7 - i)) & 1)
        self._update_labels()

    def _update_labels(self):
        val = self.get_value()
        self.binary_label.config(text="".join(str(b.value) for b in self.bits))
        self.dec_label.config(text=str(val))
        self.hex_label.config(text=f"0x{val:02X}")


# ═══════════════════════════════════════════════════════════════════
# УТИЛИТЫ КОНТРОЛЬНОЙ СУММЫ
# ═══════════════════════════════════════════════════════════════════
def xor_checksum(data):
    """Побитовое XOR всех байт."""
    result = 0
    for b in data:
        result ^= b
    return result & 0xFF


def sum_checksum(data):
    """Сумма по модулю 256."""
    return sum(data) & 0xFF


def weighted_checksum(data):
    """Взвешенная сумма: 1·b0 + 2·b1 + 3·b2 + 4·b3 mod 256."""
    result = 0
    for i, b in enumerate(data):
        result += (i + 1) * b
    return result & 0xFF


def crc8(data):
    """CRC-8 с полиномом 0x07 (как в реальных протоколах)."""
    crc = 0x00
    for b in data:
        crc ^= b
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ 0x07) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return crc


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class ChecksumApp:
    def __init__(self, root):
        self.root = root
        root.title("Контрольная сумма 4 байт")
        root.geometry("900x760")
        root.minsize(840, 720)
        root.configure(bg=BG)
        root.resizable(False, False)

        # Состояние — снимок «эталонной» суммы
        self.baseline = None
        self.baseline_bytes = None

        # ═══ Заголовок ═══════════════════════════════════════════
        tk.Label(root, text="Генератор 4 байт с контрольной суммой",
                 font=("Segoe UI", 17, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(16, 4))

        tk.Label(root,
                 text="BIN · DEC · HEX · контрольная сумма — при изменении бита сумма меняется",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 12))

        # ═══ Карточка с байтами ══════════════════════════════════
        card = tk.Frame(root, bg=CARD, highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=24, pady=(0, 10), fill="x")

        self.byte_rows = []
        for i in range(4):
            row = ByteRow(card, i, self.on_change)
            row.frame.pack(fill="x", padx=18, pady=2)
            self.byte_rows.append(row)

        # BIN слитно
        bin_row = tk.Frame(card, bg=CARD)
        bin_row.pack(fill="x", padx=18, pady=(8, 4))

        tk.Label(bin_row, text="BIN:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=MUTED, width=7, anchor="w"
                 ).pack(side="left")

        self.bin_full = tk.Label(
            bin_row, text="00000000 00000000 00000000 00000000",
            font=("Consolas", 11),
            bg=CARD, fg=BIN_COLOR, anchor="w"
        )
        self.bin_full.pack(side="left")

        # HEX слитно
        hex_row = tk.Frame(card, bg=CARD)
        hex_row.pack(fill="x", padx=18, pady=(0, 14))

        tk.Label(hex_row, text="HEX:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=MUTED, width=7, anchor="w"
                 ).pack(side="left")

        self.hex_full = tk.Label(
            hex_row, text="0x00000000",
            font=("Consolas", 12, "bold"),
            bg=CARD, fg=HEX_COLOR, anchor="w"
        )
        self.hex_full.pack(side="left")

        # ═══ Карточка контрольной суммы ══════════════════════════
        crc_card = tk.Frame(root, bg=CARD, highlightthickness=1,
                            highlightbackground=BORDER)
        crc_card.pack(padx=24, pady=(0, 10), fill="x")

        tk.Label(crc_card, text="КОНТРОЛЬНАЯ СУММА",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED
                 ).pack(anchor="w", padx=18, pady=(12, 8))

        # Таблица из 4 методов
        table = tk.Frame(crc_card, bg=CARD)
        table.pack(fill="x", padx=18, pady=(0, 6))

        headers = ["Метод", "DEC", "HEX"]
        for col, h in enumerate(headers):
            tk.Label(table, text=h,
                     font=("Segoe UI", 9, "bold"),
                     bg=CARD, fg=MUTED, anchor="w",
                     width=20 if col == 0 else 8
                     ).grid(row=0, column=col, sticky="w", padx=(0, 10))

        self.crc_labels = {}
        methods = [
            ("XOR (Искл. ИЛИ)",   xor_checksum, ACCENT),
            ("Сумма mod 256",     sum_checksum, GREEN),
            ("Взвешенная сумма",  weighted_checksum, ORANGE),
            ("CRC-8 (0x07)",      crc8, CRC_COLOR),
        ]

        for i, (name, func, color) in enumerate(methods, start=1):
            # Название
            tk.Label(table, text=name,
                     font=("Segoe UI", 10),
                     bg=CARD, fg=TEXT, anchor="w", width=20
                     ).grid(row=i, column=0, sticky="w", padx=(0, 10), pady=2)

            # DEC
            dec_lbl = tk.Label(table, text="0",
                               font=("Consolas", 12, "bold"),
                               bg=CARD, fg=color, anchor="w", width=8)
            dec_lbl.grid(row=i, column=1, sticky="w", padx=(0, 10), pady=2)

            # HEX
            hex_lbl = tk.Label(table, text="0x00",
                               font=("Consolas", 12, "bold"),
                               bg=CARD, fg=color, anchor="w", width=8)
            hex_lbl.grid(row=i, column=2, sticky="w", pady=2)

            self.crc_labels[name] = {"dec": dec_lbl, "hex": hex_lbl,
                                     "func": func, "color": color}

        # ─── Строка проверки целостности ────────────────────
        tk.Frame(crc_card, bg=BORDER, height=1
                 ).pack(fill="x", padx=18, pady=(10, 0))

        status_frame = tk.Frame(crc_card, bg=CARD)
        status_frame.pack(fill="x", padx=18, pady=(8, 14))

        self.integrity_icon = tk.Label(status_frame, text="●",
                                       font=("Segoe UI", 16, "bold"),
                                       bg=CARD, fg=GREEN)
        self.integrity_icon.pack(side="left")

        self.integrity_label = tk.Label(
            status_frame,
            text="Данные не изменялись с момента генерации",
            font=("Segoe UI", 10, "bold"),
            bg=CARD, fg=GREEN
        )
        self.integrity_label.pack(side="left", padx=(8, 0))

        # ═══ Кнопки ══════════════════════════════════════════════
        btns = tk.Frame(root, bg=BG)
        btns.pack(pady=(0, 12))

        self._make_button(btns, "🎲  Сгенерировать",
                          ACCENT, ACCENT_HOVER, ACCENT_PRESS,
                          self.generate).pack(side="left", padx=4)

        self._make_button(btns, "📌  Запомнить как эталон",
                          PURPLE, PURPLE_HOVER, PURPLE_PRESS,
                          self.snapshot).pack(side="left", padx=4)

        self._make_button(btns, "🧹  Сбросить",
                          ORANGE, ORANGE_HOVER, ORANGE_PRESS,
                          self.reset).pack(side="left", padx=4)

        self._make_button(btns, "📋  Копировать HEX",
                          GREEN, GREEN_HOVER, "#187a33",
                          self.copy_hex).pack(side="left", padx=4)

        # ═══ Клавиатура ══════════════════════════════════════════
        root.bind("<space>", lambda e: self.generate())
        root.bind("<Control-r>", lambda e: self.reset())
        root.bind("<Control-c>", lambda e: self.copy_hex())

        # ═══ Статус ══════════════════════════════════════════════
        self.status = tk.Label(root, text="",
                               font=("Segoe UI", 9),
                               bg=BG, fg=MUTED)
        self.status.pack(side="bottom", pady=(0, 12))

        # Первичная генерация
        self.generate()

    # ─── Кнопки ────────────────────────────────────────────────
    def _make_button(self, parent, text, bg, hover, press, command):
        btn = tk.Button(
            parent, text=text,
            font=("Segoe UI", 10, "bold"),
            bg=bg, fg="#ffffff",
            activebackground=press, activeforeground="#ffffff",
            bd=0, relief="flat",
            padx=16, pady=10, cursor="hand2",
            command=command,
        )
        btn.bind("<Enter>", lambda e: btn.config(bg=hover))
        btn.bind("<Leave>", lambda e: btn.config(bg=bg))
        btn.bind("<ButtonPress-1>", lambda e: btn.config(bg=press))
        btn.bind("<ButtonRelease-1>", lambda e: btn.config(bg=hover))
        return btn

    # ─── Действия ──────────────────────────────────────────────
    def generate(self):
        for row in self.byte_rows:
            row.set_value(random.randint(0, 255))
        # Запоминаем сгенерированное как эталон
        self.snapshot()
        self.status.config(text="Сгенерированы новые 4 байта · эталон обновлён",
                           fg=ACCENT)

    def snapshot(self):
        """Сохраняет текущее состояние как эталон."""
        values = [row.get_value() for row in self.byte_rows]
        self.baseline_bytes = values[:]
        self.baseline = {
            "xor": xor_checksum(values),
            "sum": sum_checksum(values),
            "weighted": weighted_checksum(values),
            "crc8": crc8(values),
        }
        self.update_integrity_status(values)
        self.status.config(text="Эталон запомнен", fg=PURPLE)

    def reset(self):
        for row in self.byte_rows:
            row.set_value(0)
        self.status.config(text="Все байты обнулены", fg=MUTED)

    def copy_hex(self):
        values = [row.get_value() for row in self.byte_rows]
        hex_str = " ".join(f"0x{v:02X}" for v in values)
        self.root.clipboard_clear()
        self.root.clipboard_append(hex_str)
        self.status.config(text=f"Скопировано: {hex_str}", fg=GREEN)

    # ─── Обновление ────────────────────────────────────────────
    def on_change(self):
        """Вызывается при любом изменении бита."""
        values = [row.get_value() for row in self.byte_rows]

        # BIN слитно
        self.bin_full.config(
            text=" ".join(f"{v:08b}" for v in values)
        )

        # HEX слитно
        self.hex_full.config(
            text="0x" + "".join(f"{v:02X}" for v in values)
        )

        # Контрольные суммы
        for name, info in self.crc_labels.items():
            result = info["func"](values)
            info["dec"].config(text=str(result))
            info["hex"].config(text=f"0x{result:02X}")

        # Проверка целостности
        self.update_integrity_status(values)

    def update_integrity_status(self, values):
        """Проверяет, изменились ли данные с момента снимка."""
        if self.baseline is None or self.baseline_bytes is None:
            return

        if values == self.baseline_bytes:
            self.integrity_icon.config(text="●", fg=GREEN)
            self.integrity_label.config(
                text="Данные совпадают с эталоном · сумма та же",
                fg=GREEN
            )
        else:
            # Считаем, сколько бит отличается
            diff_bits = 0
            for a, b in zip(self.baseline_bytes, values):
                diff_bits += bin(a ^ b).count("1")

            # Какие байты изменились
            changed = [i + 1 for i, (a, b) in
                       enumerate(zip(self.baseline_bytes, values)) if a != b]

            self.integrity_icon.config(text="⚠", fg=RED)
            self.integrity_label.config(
                text=f"Данные изменились! Изменены байты: "
                     f"{', '.join(map(str, changed))} · "
                     f"различий: {diff_bits} бит",
                fg=RED
            )


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = ChecksumApp(root)
    root.mainloop()
