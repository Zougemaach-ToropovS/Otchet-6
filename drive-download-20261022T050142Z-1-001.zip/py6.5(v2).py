import tkinter as tk


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

ACCENT = "#0a84ff"
ORANGE = "#ff9f0a"
GREEN = "#30d158"
PURPLE = "#8e44ad"
RED = "#e53935"
YELLOW = "#ffd60a"


# ═══════════════════════════════════════════════════════════════════
# НАЗВАНИЯ СПЕЦКЛАВИШ (RU / EN)
# ═══════════════════════════════════════════════════════════════════
SPECIAL_KEYS = {
    # keysym : (русское название, английское название)
    "space":     ("Пробел",              "Space"),
    "Return":    ("Enter (ввод)",         "Enter"),
    "KP_Enter":  ("Enter (ввод, нампад)", "Enter (numpad)"),
    "Tab":       ("Табуляция",            "Tab"),
    "Escape":    ("Esc (выход)",          "Esc"),
    "BackSpace": ("Backspace (удалить)",  "Backspace"),
    "Delete":    ("Delete (удалить)",     "Delete"),
    "Insert":    ("Insert (вставка)",     "Insert"),
    "Home":      ("Home (в начало)",      "Home"),
    "End":       ("End (в конец)",        "End"),
    "Prior":     ("Page Up",              "Page Up"),
    "Next":      ("Page Down",            "Page Down"),
    "Left":      ("← Стрелка влево",      "← Left arrow"),
    "Right":     ("→ Стрелка вправо",     "→ Right arrow"),
    "Up":        ("↑ Стрелка вверх",      "↑ Up arrow"),
    "Down":      ("↓ Стрелка вниз",       "↓ Down arrow"),
    "Control_L": ("Ctrl (левый)",         "Ctrl (left)"),
    "Control_R": ("Ctrl (правый)",        "Ctrl (right)"),
    "Shift_L":   ("Shift (левый)",        "Shift (left)"),
    "Shift_R":   ("Shift (правый)",       "Shift (right)"),
    "Alt_L":     ("Alt (левый)",          "Alt (left)"),
    "Alt_R":     ("Alt (right)",          "Alt (right)"),
    "Caps_Lock": ("Caps Lock",            "Caps Lock"),
    "Num_Lock":  ("Num Lock",             "Num Lock"),
    "Scroll_Lock": ("Scroll Lock",        "Scroll Lock"),
    "Pause":     ("Pause",                "Pause"),
    "Print":     ("Print Screen",         "Print Screen"),
    "Menu":      ("Контекстное меню",     "Context menu"),
    "Super_L":   ("Win (левый)",          "Win (left)"),
    "Super_R":   ("Win (правый)",         "Win (right)"),
}

# F1–F12 — не выводятся
FUNCTION_KEYS = {f"F{i}" for i in range(1, 13)}


# ═══════════════════════════════════════════════════════════════════
# КОДИРОВКИ
# ═══════════════════════════════════════════════════════════════════
def to_ascii(ch):
    code = ord(ch)
    return code if 0 <= code <= 127 else None


def to_unicode(ch):
    return ord(ch)


def to_cp1251(ch):
    try:
        return ch.encode("cp1251")[0]
    except (UnicodeEncodeError, IndexError):
        return None


def to_cp866(ch):
    try:
        return ch.encode("cp866")[0]
    except (UnicodeEncodeError, IndexError):
        return None


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class KeyCodeApp:
    def __init__(self, root):
        self.root = root
        root.title("Коды символов нажатых клавиш")
        root.geometry("880x860")
        root.minsize(820, 820)
        root.configure(bg=BG)
        root.resizable(False, False)

        self.history = []
        self.lang = tk.StringVar(value="ru")   # ru / en

        # ═══ Заголовок ═══════════════════════════════════════════
        tk.Label(root, text="Коды символов нажатых клавиш",
                 font=("Segoe UI", 16, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(14, 3))

        tk.Label(root,
                 text="Нажмите клавишу — увидите код в 4 кодировках",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 10))

        # ═══ Переключатель языка ═════════════════════════════════
        lang_row = tk.Frame(root, bg=BG)
        lang_row.pack(pady=(0, 8))

        tk.Label(lang_row, text="Язык названий:",
                 font=("Segoe UI", 10, "bold"),
                 bg=BG, fg=TEXT).pack(side="left", padx=(0, 10))

        for value, text in [("ru", "Русский"), ("en", "English")]:
            tk.Radiobutton(
                lang_row, text=text,
                variable=self.lang, value=value,
                font=("Segoe UI", 10),
                bg=BG, fg=TEXT, selectcolor=CARD,
                activebackground=BG, activeforeground=ACCENT,
                bd=0, highlightthickness=0, cursor="hand2",
            ).pack(side="left", padx=(0, 12))

        # ═══ Область захвата ═════════════════════════════════════
        self.capture = tk.Frame(root, bg=CARD,
                                highlightthickness=2,
                                highlightbackground=ACCENT)
        self.capture.pack(padx=24, pady=(0, 10), fill="x")

        self.capture_label = tk.Label(
            self.capture, text="⌨  Нажмите клавишу здесь",
            font=("Segoe UI", 12),
            bg=CARD, fg=MUTED,
            padx=20, pady=18,
        )
        self.capture_label.pack()

        for w in (self.capture, self.capture_label):
            w.bind("<Button-1>", self.grab_focus)

        # Фокус на главном окне
        root.bind("<Key>", self.on_key)
        root.focus_set()

        # ═══ Карточка символа ════════════════════════════════════
        symbol_card = tk.Frame(root, bg=CARD,
                               highlightthickness=1,
                               highlightbackground=BORDER)
        symbol_card.pack(padx=24, pady=(0, 10), fill="x")

        tk.Label(symbol_card, text="НАЖАТА КЛАВИША",
                 font=("Segoe UI", 8, "bold"),
                 bg=CARD, fg=MUTED).pack(pady=(10, 2))

        self.symbol_display = tk.Label(
            symbol_card, text="—",
            font=("Consolas", 40, "bold"),
            bg=CARD, fg=ACCENT, pady=4,
        )
        self.symbol_display.pack()

        self.key_name = tk.Label(
            symbol_card, text="",
            font=("Consolas", 10),
            bg=CARD, fg=MUTED, pady=(0, 10),
        )
        self.key_name.pack()

        # ═══ Таблица кодировок ═══════════════════════════════════
        table_card = tk.Frame(root, bg=CARD,
                              highlightthickness=1,
                              highlightbackground=BORDER)
        table_card.pack(padx=24, pady=(0, 10), fill="x")

        tk.Label(table_card, text="КОДИРОВКИ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED
                 ).pack(anchor="w", padx=18, pady=(12, 6))

        table = tk.Frame(table_card, bg=CARD)
        table.pack(fill="x", padx=18, pady=(0, 14))

        headers = ["Кодировка", "DEC", "HEX", "BIN", "Символ"]
        widths = [14, 8, 7, 12, 6]
        for col, (h, w) in enumerate(zip(headers, widths)):
            tk.Label(table, text=h,
                     font=("Segoe UI", 9, "bold"),
                     bg=CARD, fg=MUTED,
                     width=w, anchor="w"
                     ).grid(row=0, column=col, sticky="w", padx=(0, 8))

        self.rows = {}
        codings = [
            ("ASCII",   to_ascii,   ORANGE),
            ("Unicode", to_unicode, ACCENT),
            ("CP1251",  to_cp1251,  GREEN),
            ("CP866",   to_cp866,   PURPLE),
        ]

        for i, (name, func, color) in enumerate(codings, start=1):
            tk.Label(table, text=name,
                     font=("Segoe UI", 10, "bold"),
                     bg=CARD, fg=color,
                     width=14, anchor="w"
                     ).grid(row=i, column=0, sticky="w", padx=(0, 8), pady=3)

            dec = tk.Label(table, text="—",
                           font=("Consolas", 11, "bold"),
                           bg=CARD, fg=TEXT, width=8, anchor="w")
            dec.grid(row=i, column=1, sticky="w", padx=(0, 8), pady=3)

            hexl = tk.Label(table, text="—",
                            font=("Consolas", 11),
                            bg=CARD, fg=MUTED, width=7, anchor="w")
            hexl.grid(row=i, column=2, sticky="w", padx=(0, 8), pady=3)

            binl = tk.Label(table, text="—",
                            font=("Consolas", 10),
                            bg=CARD, fg=MUTED, width=12, anchor="w")
            binl.grid(row=i, column=3, sticky="w", padx=(0, 8), pady=3)

            sym = tk.Label(table, text="",
                           font=("Segoe UI", 12, "bold"),
                           bg=CARD, fg=color, width=6, anchor="w")
            sym.grid(row=i, column=4, sticky="w", pady=3)

            self.rows[name] = {
                "dec": dec, "hex": hexl, "bin": binl, "sym": sym,
                "func": func, "color": color,
            }

        # ═══ Предупреждение о F1–F12 ═════════════════════════════
        warn_card = tk.Frame(root, bg="#fff9e6",
                             highlightthickness=1,
                             highlightbackground=YELLOW)
        warn_card.pack(padx=24, pady=(0, 10), fill="x")

        tk.Label(warn_card,
                 text="⚠  Функциональные клавиши F1–F12 не выводятся в кодах "
                      "(это не символы, а команды системы)",
                 font=("Segoe UI", 9, "bold"),
                 bg="#fff9e6", fg="#7a5a00",
                 wraplength=780, justify="left"
                 ).pack(padx=14, pady=10, anchor="w")

        # ═══ История ═════════════════════════════════════════════
        hist_card = tk.Frame(root, bg=CARD,
                             highlightthickness=1,
                             highlightbackground=BORDER)
        hist_card.pack(padx=24, pady=(0, 10), fill="both", expand=True)

        tk.Label(hist_card, text="ПОСЛЕДНИЕ НАЖАТИЯ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED
                 ).pack(anchor="w", padx=18, pady=(12, 6))

        self.history_box = tk.Text(
            hist_card, height=5,
            font=("Consolas", 10),
            bg="#fafafa", fg=TEXT,
            bd=0, relief="flat",
            highlightthickness=0,
            padx=14, pady=8,
            state="disabled", wrap="word",
        )
        self.history_box.pack(fill="both", expand=True, padx=18, pady=(0, 12))

        # ═══ Статус ══════════════════════════════════════════════
        self.status = tk.Label(root, text="Ожидание нажатия клавиши…",
                               font=("Segoe UI", 9),
                               bg=BG, fg=MUTED)
        self.status.pack(side="bottom", pady=(0, 10))

    # ─── Фокус ─────────────────────────────────────────────────
    def grab_focus(self, event=None):
        self.root.focus_set()

    # ─── Обработка клавиши ─────────────────────────────────────
    def on_key(self, event):
        keysym = event.keysym

        # F1–F12 — не выводим
        if keysym in FUNCTION_KEYS:
            self._show_function_key(keysym)
            return

        # Спецклавиша — показываем название
        if keysym in SPECIAL_KEYS:
            self._show_special_key(keysym)
            return

        # Обычный символ
        char = event.char
        if char and char != "\x00":
            self._show_char(char, event)
        else:
            # Неизвестная клавиша — тоже как спец
            self._show_special_key(keysym)

    # ─── Обычный символ ────────────────────────────────────────
    def _show_char(self, char, event):
        code = ord(char)
        self.symbol_display.config(text=char, fg=ACCENT)
        self.key_name.config(
            text=f"keysym: {event.keysym}  ·  Unicode: U+{code:04X}"
        )

        for name, row in self.rows.items():
            value = row["func"](char)
            if value is None:
                row["dec"].config(text="не входит", fg=RED,
                                  font=("Segoe UI", 9))
                row["hex"].config(text="—", fg=MUTED)
                row["bin"].config(text="—", fg=MUTED)
                row["sym"].config(text="?", fg=RED)
            else:
                row["dec"].config(text=str(value), fg=TEXT,
                                  font=("Consolas", 11, "bold"))
                row["hex"].config(text=f"0x{value:02X}", fg=MUTED)
                row["bin"].config(text=f"{value:08b}", fg=MUTED)
                row["sym"].config(text=char, fg=row["color"])

        self._add_history(char, code, event.keysym)
        self.status.config(
            text=f"Символ '{char}'  ·  Unicode U+{code:04X}",
            fg=GREEN
        )

    # ─── Спецклавиша ───────────────────────────────────────────
    def _show_special_key(self, keysym):
        ru_name, en_name = SPECIAL_KEYS.get(
            keysym, (keysym, keysym)
        )
        name = ru_name if self.lang.get() == "ru" else en_name

        # Показываем название как «символ»
        self.symbol_display.config(text="⌨", fg=ORANGE)
        self.key_name.config(
            text=f"Служебная клавиша: {name}  (keysym: {keysym})"
        )

        # Очищаем таблицу кодировок — у спецклавиш нет символьного кода
        for row in self.rows.values():
            row["dec"].config(text="—", fg=MUTED,
                              font=("Consolas", 11, "bold"))
            row["hex"].config(text="—", fg=MUTED)
            row["bin"].config(text="—", fg=MUTED)
            row["sym"].config(text="", fg=row["color"])

        self._add_history(f"[{name}]", None, keysym)
        self.status.config(
            text=f"Нажата служебная клавиша: {name}  ({keysym})",
            fg=ORANGE
        )

    # ─── Функциональная клавиша F1–F12 ─────────────────────────
    def _show_function_key(self, keysym):
        msg = ("Функциональные клавиши F1–F12 не выводятся, "
               "так как не имеют символьного кода")
        msg_short = f"{keysym}: не имеет кода символа"

        self.symbol_display.config(text="—", fg=MUTED)
        self.key_name.config(text=msg_short)

        for row in self.rows.values():
            row["dec"].config(text="—", fg=MUTED,
                              font=("Consolas", 11, "bold"))
            row["hex"].config(text="—", fg=MUTED)
            row["bin"].config(text="—", fg=MUTED)
            row["sym"].config(text="", fg=row["color"])

        self.status.config(text=f"{keysym}: не имеет кода символа", fg=RED)

    # ─── История ───────────────────────────────────────────────
    def _add_history(self, display, code, keysym):
        if code is None:
            line = f"{display:<15}  key={keysym:<10}  (без символьного кода)"
        else:
            a = to_ascii(display) if len(display) == 1 else None
            u = code
            c1 = to_cp1251(display) if len(display) == 1 else None
            c8 = to_cp866(display) if len(display) == 1 else None

            def fmt(v):
                return f"{v:5d}" if v is not None else "    —"

            line = (f"'{display}'  key={keysym:<10}  "
                    f"ASCII={fmt(a)}  Uni={fmt(u)}  "
                    f"CP1251={fmt(c1)}  CP866={fmt(c8)}")

        self.history.append(line)
        if len(self.history) > 30:
            self.history = self.history[-30:]

        self.history_box.config(state="normal")
        self.history_box.delete("1.0", tk.END)
        for h in self.history:
            self.history_box.insert(tk.END, h + "\n")
        self.history_box.see(tk.END)
        self.history_box.config(state="disabled")


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = KeyCodeApp(root)
    root.mainloop()
