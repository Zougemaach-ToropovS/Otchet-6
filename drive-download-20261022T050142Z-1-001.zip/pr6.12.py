import tkinter as tk
import random
import base64


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

OK = "#30d158"
WARN = "#ff9f0a"
ALARM = "#ff3b30"
ACCENT = "#0a84ff"
HIGHLIGHT = "#fff3cd"   # жёлтый фон для изменённых бит

ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
RED = "#e53935"
RED_HOVER = "#c62828"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class BitErrorApp:
    def __init__(self, root):
        self.root = root
        root.title("Влияние искажений на битовом уровне")
        root.geometry("1100x860")
        root.minsize(1000, 820)
        root.configure(bg=BG)
        root.resizable(False, False)

        self.original_text = "Привет, мир!"
        self.corrupted_bytes = b""
        self.flipped_positions = set()

        self._build_header()
        self._build_input()
        self._build_stats()
        self._build_visual()
        self._build_controls()

        self.apply()

    # ════════════════════════════════════════════════════════════
    # ЗАГОЛОВОК
    # ════════════════════════════════════════════════════════════
    def _build_header(self):
        tk.Label(self.root, text="Влияние искажений (битовых ошибок) на текст",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(12, 2))

        tk.Label(self.root,
                 text="Меняем 1, 2, 3… бит — и смотрим, как меняется читаемость",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

    # ════════════════════════════════════════════════════════════
    # ВВОД
    # ════════════════════════════════════════════════════════════
    def _build_input(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=20, pady=(0, 8), fill="x")

        row = tk.Frame(card, bg=CARD)
        row.pack(fill="x", padx=16, pady=10)

        tk.Label(row, text="Текст:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 8))

        self.entry = tk.Entry(row, font=("Consolas", 12),
                              bg="#fafafa", fg=TEXT,
                              bd=1, relief="solid",
                              highlightthickness=1,
                              highlightbackground=BORDER,
                              highlightcolor=ACCENT)
        self.entry.pack(side="left", fill="x", expand=True, ipady=5,
                        padx=(0, 8))
        self.entry.insert(0, self.original_text)

        self._btn(row, "Случайно", ACCENT, ACCENT_HOVER,
                  self.random_text).pack(side="left", padx=2)

        # Ползунок количества искажений
        row2 = tk.Frame(card, bg=CARD)
        row2.pack(fill="x", padx=16, pady=(0, 12))

        tk.Label(row2, text="Количество искажённых бит:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 10))

        self.error_count_lbl = tk.Label(row2, text="3",
                                        font=("Consolas", 14, "bold"),
                                        bg=CARD, fg=ALARM, width=4)
        self.error_count_lbl.pack(side="left", padx=(0, 10))

        self.error_scale = tk.Scale(row2, from_=1, to=40,
                                    orient="horizontal",
                                    length=350, showvalue=False,
                                    bg=CARD, fg=TEXT, troughcolor="#ececf0",
                                    activebackground=ALARM,
                                    highlightthickness=0, bd=0,
                                    sliderlength=18, width=10,
                                    command=self.on_error_count_change)
        self.error_scale.set(3)
        self.error_scale.pack(side="left", padx=(0, 10))

        self._btn(row2, "🎯 Исказить", ORANGE, ORANGE_HOVER,
                  self.apply).pack(side="left", padx=2)
        self._btn(row2, "↻ Сброс", RED, RED_HOVER,
                  self.reset_errors).pack(side="left", padx=2)

    def random_text(self):
        samples = [
            "Привет, мир!",
            "Hello, World!",
            "Проверка связи",
            "ABCDEFGH",
            "Тест искажений",
            "0123456789",
        ]
        self.entry.delete(0, tk.END)
        self.entry.insert(0, random.choice(samples))
        self.apply()

    def on_error_count_change(self, v):
        self.error_count_lbl.config(text=str(int(float(v))))

    # ════════════════════════════════════════════════════════════
    # СТАТИСТИКА
    # ════════════════════════════════════════════════════════════
    def _build_stats(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=20, pady=(0, 8), fill="x")

        inner = tk.Frame(card, bg=CARD)
        inner.pack(fill="x", padx=16, pady=10)

        self.stat_bits = self._stat(inner, "Бит изменено", "0", ALARM)
        self.stat_chars = self._stat(inner, "Символов изменено", "0", WARN)
        self.stat_visible = self._stat(inner, "Читаемость", "—", OK)
        self.stat_b64 = self._stat(inner, "Длина Base64", "0", ACCENT)

    def _stat(self, parent, label, value, color):
        f = tk.Frame(parent, bg=CARD)
        f.pack(side="left", padx=(0, 30))

        tk.Label(f, text=label,
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w")

        lbl = tk.Label(f, text=value,
                       font=("Consolas", 16, "bold"),
                       bg=CARD, fg=color, anchor="w")
        lbl.pack(anchor="w")
        return lbl

    # ════════════════════════════════════════════════════════════
    # ВИЗУАЛИЗАЦИЯ СИМВОЛОВ
    # ════════════════════════════════════════════════════════════
    def _build_visual(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=20, pady=(0, 8), fill="both", expand=True)

        tk.Label(card, text="ПОСИМВОЛЬНОЕ СРАВНЕНИЕ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=16, pady=(10, 4))

        wrap = tk.Frame(card, bg=CARD)
        wrap.pack(fill="both", expand=True, padx=16, pady=(0, 12))

        self.visual_text = tk.Text(wrap,
                                   font=("Consolas", 11),
                                   bg="#fafafa", fg=TEXT,
                                   bd=0, relief="flat",
                                   highlightthickness=0,
                                   wrap="word",
                                   padx=10, pady=8,
                                   state="disabled")
        self.visual_text.pack(side="left", fill="both", expand=True)

        sb = tk.Scrollbar(wrap, command=self.visual_text.yview,
                          bd=0, relief="flat", width=10)
        sb.pack(side="right", fill="y")
        self.visual_text.config(yscrollcommand=sb.set)

        # Теги
        self.visual_text.tag_configure("header",
                                       foreground=ACCENT,
                                       font=("Consolas", 10, "bold"))
        self.visual_text.tag_configure("muted", foreground=MUTED)
        self.visual_text.tag_configure("changed", foreground=ALARM,
                                       background=HIGHLIGHT)
        self.visual_text.tag_configure("normal", foreground=TEXT)
        self.visual_text.tag_configure("error_symbol", foreground=ALARM,
                                       font=("Consolas", 13, "bold"))

    # ════════════════════════════════════════════════════════════
    # КНОПКИ
    # ════════════════════════════════════════════════════════════
    def _build_controls(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=20, pady=(0, 16), fill="x")

        inner = tk.Frame(card, bg=CARD)
        inner.pack(fill="x", padx=16, pady=10)

        tk.Label(inner, text="Быстрые тесты:",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED).pack(side="left", padx=(0, 10))

        for n in (1, 2, 3, 5, 8, 16, 32):
            self._btn(inner, f"{n} бит",
                      ACCENT, ACCENT_HOVER,
                      lambda x=n: self.quick_test(x)).pack(side="left", padx=2)

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 9, "bold"),
                        bg=bg, fg="#ffffff",
                        activebackground=hover,
                        activeforeground="#ffffff",
                        bd=0, padx=10, pady=6, cursor="hand2",
                        command=command)

        def on_enter(e): btn.config(bg=hover)

        def on_leave(e): btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    def quick_test(self, n):
        self.error_scale.set(n)
        self.error_count_lbl.config(text=str(n))
        self.apply()

    # ════════════════════════════════════════════════════════════
    # ЛОГИКА
    # ════════════════════════════════════════════════════════════
    def apply(self):
        """Кодирует текст в UTF-8, искажает N случайных бит."""
        text = self.entry.get()
        if not text:
            text = "Привет"
            self.entry.delete(0, tk.END)
            self.entry.insert(0, text)

        self.original_text = text
        original_bytes = text.encode("utf-8")

        n_errors = int(self.error_scale.get())
        total_bits = len(original_bytes) * 8
        n_errors = min(n_errors, total_bits)

        # Выбираем N случайных позиций бит
        positions = random.sample(range(total_bits), n_errors)
        self.flipped_positions = set(positions)

        # Искажаем
        corrupted = bytearray(original_bytes)
        for pos in positions:
            byte_idx = pos // 8
            bit_idx = pos % 8
            corrupted[byte_idx] ^= (1 << (7 - bit_idx))

        self.corrupted_bytes = bytes(corrupted)

        # Обновляем UI
        self._update_stats(original_bytes, self.corrupted_bytes, n_errors)
        self._update_visual(original_bytes, self.corrupted_bytes)

    def reset_errors(self):
        self.error_scale.set(0) if self.error_scale.cget("from") == 0 else None
        # Сбрасываем количество искажений в 0 (через минимум)
        self.error_scale.set(1)
        # Находим позицию «без ошибок» — 1 бит всё равно меняет
        # Поэтому просто делаем 1 бит, чтобы не ломать логику
        # (или можно добавить отдельный «без искажений»)
        self.error_scale.set(1)
        self.error_count_lbl.config(text="0")
        self.error_scale.set(1)
        self.entry.delete(0, tk.END)
        self.entry.insert(0, "Привет, мир!")
        self.error_scale.set(1)
        self._set_no_errors()

    def _set_no_errors(self):
        """Показать оригинал без искажений."""
        text = self.entry.get()
        self.original_text = text
        original_bytes = text.encode("utf-8")
        self.corrupted_bytes = original_bytes
        self.flipped_positions = set()

        self.stat_bits.config(text="0")
        self.stat_chars.config(text="0")
        self.stat_visible.config(text="100%", fg=OK)

        self.visual_text.config(state="normal")
        self.visual_text.delete("1.0", "end")
        self.visual_text.insert(
            "end", "Без искажений — текст читается идеально.\n\n",
            "header")
        self.visual_text.insert("end", f"Текст: {text}\n\n", "normal")
        self.visual_text.insert("end", "HEX:\n", "header")
        self.visual_text.insert(
            "end", " ".join(f"{b:02X}" for b in original_bytes) + "\n\n",
            "muted")
        self.visual_text.insert("end", "BIN:\n", "header")
        self.visual_text.insert(
            "end", " ".join(f"{b:08b}" for b in original_bytes) + "\n",
            "muted")
        self.visual_text.config(state="disabled")

    # ════════════════════════════════════════════════════════════
    # ОБНОВЛЕНИЕ СТАТИСТИКИ
    # ════════════════════════════════════════════════════════════
    def _update_stats(self, original, corrupted, n_errors):
        self.stat_bits.config(text=str(n_errors))

        # Сколько символов изменилось
        changed_chars = sum(1 for a, b in zip(original, corrupted) if a != b)
        self.stat_chars.config(text=str(changed_chars))

        # Читаемость
        if n_errors == 0:
            readability = 100
            color = OK
        elif n_errors <= 2:
            readability = 90
            color = OK
        elif n_errors <= 5:
            readability = 60
            color = WARN
        elif n_errors <= 10:
            readability = 30
            color = WARN
        else:
            readability = 5
            color = ALARM

        self.stat_visible.config(
            text=f"{readability}%", fg=color)

        # Base64 длина
        try:
            b64 = base64.b64encode(corrupted).decode("ascii")
            self.stat_b64.config(text=str(len(b64)))
        except Exception:
            self.stat_b64.config(text="—")

    # ════════════════════════════════════════════════════════════
    # ПОСИМВОЛЬНАЯ ВИЗУАЛИЗАЦИЯ
    # ════════════════════════════════════════════════════════════
    def _update_visual(self, original, corrupted):
        self.visual_text.config(state="normal")
        self.visual_text.delete("1.0", "end")

        # Заголовок
        self.visual_text.insert("end",
                                "ОРИГИНАЛ:\n", "header")
        self.visual_text.insert("end",
                                f"  {original.decode('utf-8', errors='replace')}\n\n",
                                "normal")

        # Искажённый
        self.visual_text.insert("end",
                                "ИСКАЖЁННЫЙ ТЕКСТ:\n", "header")
        corrupted_text = corrupted.decode("utf-8", errors="replace")
        self.visual_text.insert("end", f"  {corrupted_text}\n\n", "normal")

        # Подсветка изменённых символов
        self.visual_text.insert("end",
                                "ПОСИМВОЛЬНО (красные — повреждены):\n", "header")

        for i in range(len(original)):
            a = original[i]
            b = corrupted[i]

            if a != b:
                # Символ изменён
                try:
                    a_ch = bytes([a]).decode("utf-8")
                except Exception:
                    a_ch = "?"
                try:
                    b_ch = bytes([b]).decode("utf-8", errors="replace")
                except Exception:
                    b_ch = "?"

                self.visual_text.insert(
                    "end",
                    f"  [{i:02d}] {a_ch!r:>4} → {b_ch!r:>4}  ",
                    "changed")
                self.visual_text.insert(
                    "end",
                    f"HEX: {a:02X} → {b:02X}  "
                    f"BIN: {a:08b} → {b:08b}\n",
                    "muted")
            else:
                try:
                    a_ch = bytes([a]).decode("utf-8")
                except Exception:
                    a_ch = "?"
                self.visual_text.insert(
                    "end",
                    f"  [{i:02d}] {a_ch!r:>4}    "
                    f"HEX: {a:02X}    "
                    f"BIN: {a:08b}\n",
                    "normal")

        # Общая битовая карта
        self.visual_text.insert("end",
                                "\nПОБИТОВОЕ СРАВНЕНИЕ:\n", "header")

        total_bits = len(original) * 8
        for i in range(len(original)):
            line_a = f"{original[i]:08b}"
            line_b = f"{corrupted[i]:08b}"

            self.visual_text.insert(
                "end", f"  [{i:02d}] ", "muted")

            # Посимвольно: одинаковые символы — обычным цветом, разные — красным
            for j in range(8):
                bit_pos = i * 8 + j
                if bit_pos in self.flipped_positions:
                    self.visual_text.insert(
                        "end", f"{line_b[j]}", "changed")
                else:
                    self.visual_text.insert(
                        "end", f"{line_a[j]}", "normal")

            self.visual_text.insert(
                "end",
                f"  (было: {line_a})\n", "muted")

        # Пояснение
        self.visual_text.insert("end", "\nПОЯСНЕНИЕ:\n", "header")
        self.visual_text.insert(
            "end",
            "• 1 бит в символе → символ заменяется другим (например, 'A' → '@').\n"
            "• 8 бит в символе → символ полностью ломается (становится '?' или нечитаемым).\n"
            "• UTF-8: русские буквы занимают 2 байта (16 бит) — 1 бит тоже ломает символ.\n"
            "• Base64 кодирует байты, а не символы — 1 бит в байте → +1 другой символ в Base64.\n",
            "muted")

        self.visual_text.config(state="disabled")


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = BitErrorApp(root)
    root.mainloop()
