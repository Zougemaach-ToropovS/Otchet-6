import tkinter as tk
import math


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

AXIS_COLOR = "#000000"
GRID_COLOR = "#ececf0"
WAVE_COLOR = "#e53935"       # красная волна
POINT_COLOR = "#e53935"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
ACCENT_PRESS = "#004c99"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class HarmonicApp:
    def __init__(self, root):
        self.root = root
        root.title("Гармоническое колебание")
        root.geometry("1120x800")
        root.minsize(1020, 760)
        root.configure(bg=BG)
        root.resizable(False, False)

        # Состояние
        self.running = False
        self.time = 0.0                # виртуальное время
        self.amp = 1.0                 # амплитуда
        self.freq = 1.0                # частота, Гц
        self.phase = 0.0               # фаза, рад
        self.speed = 1.0               # скорость анимации

        # ═══ Заголовок ═══════════════════════════════════════════
        tk.Label(root, text="Гармоническое колебание",
                 font=("Segoe UI", 16, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(14, 3))

        self.formula = tk.Label(
            root,
            text="y(t) = A · sin(2π · f · t + φ)",
            font=("Consolas", 12),
            bg=BG, fg=ACCENT,
        )
        self.formula.pack(pady=(0, 10))

        # ═══ Карточка с графиком ═════════════════════════════════
        card = tk.Frame(root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=24, pady=(0, 10))

        self.canvas = tk.Canvas(card, width=1040, height=360,
                                bg="white", highlightthickness=0)
        self.canvas.pack(padx=15, pady=15)

        # ═══ Значение y(t) ═══════════════════════════════════════
        self.value_label = tk.Label(
            root, text="y(t) = 0.000",
            font=("Consolas", 14, "bold"),
            bg=BG, fg=WAVE_COLOR,
        )
        self.value_label.pack(pady=(0, 10))

        # ═══ Панель управления ═══════════════════════════════════
        ctrl = tk.Frame(root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        ctrl.pack(padx=24, pady=(0, 12), fill="x")

        # ─── Амплитуда ──────────────────────────────────────
        self.amp_scale = self._make_slider(
            ctrl, "Амплитуда A", 0.1, 3.0, 1.0, 0.05,
            lambda v: self._set_amp(v),
            SIN_COLOR=WAVE_COLOR,
        )

        # ─── Частота ────────────────────────────────────────
        self.freq_scale = self._make_slider(
            ctrl, "Частота f, Гц", 0.1, 5.0, 1.0, 0.1,
            lambda v: self._set_freq(v),
            SIN_COLOR=ACCENT,
        )

        # ─── Фаза ───────────────────────────────────────────
        self.phase_scale = self._make_slider(
            ctrl, "Фаза φ, рад", 0.0, 2 * math.pi, 0.0, 0.1,
            lambda v: self._set_phase(v),
            SIN_COLOR="#8e44ad",
        )

        # ─── Скорость ───────────────────────────────────────
        self.speed_scale = self._make_slider(
            ctrl, "Скорость анимации", 0.1, 3.0, 1.0, 0.1,
            lambda v: self._set_speed(v),
            SIN_COLOR=GREEN,
        )

        # ═══ Кнопки ══════════════════════════════════════════════
        btns = tk.Frame(root, bg=BG)
        btns.pack(pady=(0, 16))

        self.btn_play = tk.Button(
            btns, text="▶  Старт",
            font=("Segoe UI", 11, "bold"),
            bg=GREEN, fg="#ffffff",
            activebackground=GREEN_HOVER, activeforeground="#ffffff",
            bd=0, padx=24, pady=12, cursor="hand2",
            command=self.toggle_play,
        )
        self.btn_play.pack(side="left", padx=4)

        self.btn_stop = tk.Button(
            btns, text="⏺  Стоп",
            font=("Segoe UI", 11, "bold"),
            bg=ORANGE, fg="#ffffff",
            activebackground=ORANGE_HOVER, activeforeground="#ffffff",
            bd=0, padx=24, pady=12, cursor="hand2",
            command=self.stop,
        )
        self.btn_stop.pack(side="left", padx=4)

        self.btn_reset = tk.Button(
            btns, text="↻  Сброс",
            font=("Segoe UI", 11, "bold"),
            bg=ACCENT, fg="#ffffff",
            activebackground=ACCENT_HOVER, activeforeground="#ffffff",
            bd=0, padx=24, pady=12, cursor="hand2",
            command=self.reset,
        )
        self.btn_reset.pack(side="left", padx=4)

        # ═══ Клавиатура ══════════════════════════════════════════
        root.bind("<space>", lambda e: self.toggle_play())
        root.bind("<Escape>", lambda e: self.stop())
        root.bind("<Control-r>", lambda e: self.reset())

        # Стартуем сразу в режиме «играет»
        self.start()

    # ─── Слайдер ───────────────────────────────────────────────
    def _make_slider(self, parent, label, vmin, vmax, initial, step,
                     callback, SIN_COLOR=ACCENT):
        frame = tk.Frame(parent, bg=CARD)
        frame.pack(side="left", padx=(16, 0), pady=12, fill="x", expand=True)

        header = tk.Frame(frame, bg=CARD)
        header.pack(fill="x")

        tk.Label(header, text=label,
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED).pack(side="left")

        value_label = tk.Label(header, text=f"{initial:g}",
                               font=("Consolas", 11, "bold"),
                               bg=CARD, fg=SIN_COLOR)
        value_label.pack(side="right")

        scale = tk.Scale(
            frame, from_=vmin, to=vmax, resolution=step,
            orient="horizontal", showvalue=False,
            bg=CARD, fg=TEXT, troughcolor="#e8e8ec",
            activebackground=SIN_COLOR,
            highlightthickness=0, bd=0,
            sliderlength=18, width=8,
            command=lambda v: (callback(float(v)),
                               value_label.config(text=f"{float(v):g}")),
        )
        scale.set(initial)
        scale.pack(fill="x", pady=(4, 0))
        return scale

    # ─── Обработчики слайдеров ─────────────────────────────────
    def _set_amp(self, v):
        self.amp = v

    def _set_freq(self, v):
        self.freq = v

    def _set_phase(self, v):
        self.phase = v

    def _set_speed(self, v):
        self.speed = v

    # ─── Управление воспроизведением ───────────────────────────
    def start(self):
        self.running = True
        self.btn_play.config(text="⏸  Пауза",
                             bg=ORANGE,
                             activebackground=ORANGE_HOVER)
        self._tick()

    def stop(self):
        self.running = False
        self.time = 0.0
        self.btn_play.config(text="▶  Старт",
                             bg=GREEN,
                             activebackground=GREEN_HOVER)
        self.redraw()

    def toggle_play(self):
        if self.running:
            self.running = False
            self.btn_play.config(text="▶  Старт",
                                 bg=GREEN,
                                 activebackground=GREEN_HOVER)
        else:
            self.start()

    def reset(self):
        self.running = False
        self.time = 0.0
        self.amp = 1.0
        self.freq = 1.0
        self.phase = 0.0
        self.speed = 1.0

        self.amp_scale.set(1.0)
        self.freq_scale.set(1.0)
        self.phase_scale.set(0.0)
        self.speed_scale.set(1.0)

        self.btn_play.config(text="▶  Старт",
                             bg=GREEN,
                             activebackground=GREEN_HOVER)
        self.redraw()

    # ─── Тик анимации ──────────────────────────────────────────
    def _tick(self):
        if not self.running:
            return

        # Обновляем виртуальное время
        self.time += 0.016 * self.speed      # ~16 мс * скорость

        self.redraw()

        # 30 FPS
        self.root.after(33, self._tick)

    # ─── Отрисовка ─────────────────────────────────────────────
    def redraw(self):
        c = self.canvas
        c.delete("all")

        W = 1040
        H = 360
        x0, x1 = 70, W - 30
        y0, y1 = 30, H - 40

        # Амплитуда по оси Y с запасом
        A = max(self.amp, 0.5)
        ymin = -A - 0.3
        ymax = A + 0.3

        # Окно времени — показываем 4 секунды
        window = 4.0
        t_start = self.time - window
        t_end = self.time

        def to_px(t):
            return x0 + (t - t_start) / (t_end - t_start) * (x1 - x0)

        def to_py(y):
            return y1 - (y - ymin) / (ymax - ymin) * (y1 - y0)

        # ═══ Сетка ══════════════════════════════════════════════
        # Вертикальная (по времени)
        for i in range(9):
            t = t_start + (t_end - t_start) * i / 8
            px = to_px(t)
            c.create_line(px, y0, px, y1, fill=GRID_COLOR)

        # Горизонтальная (по амплитуде)
        for i in range(-4, 5):
            y_val = i * A / 4
            py = to_py(y_val)
            c.create_line(x0, py, x1, py, fill=GRID_COLOR)

        # ═══ Оси ════════════════════════════════════════════════
        cy = to_py(0)

        # Ось X
        c.create_line(x0 - 15, cy, x1 + 15, cy,
                      fill=AXIS_COLOR, width=1,
                      arrow="last", arrowshape=(10, 12, 4))
        # Ось Y
        c.create_line(x0, y1 + 10, x0, y0 - 10,
                      fill=AXIS_COLOR, width=1,
                      arrow="last", arrowshape=(10, 12, 4))

        # Подписи осей
        c.create_text(x1 + 20, cy + 14, text="t, с",
                      font=("Segoe UI", 10, "italic"), fill=TEXT)
        c.create_text(x0 - 12, y0 - 20, text="y",
                      font=("Segoe UI", 10, "italic"), fill=TEXT)

        # ═══ Деления оси Y ══════════════════════════════════════
        for y_val in (-A, -A / 2, A / 2, A):
            py = to_py(y_val)
            c.create_line(x0 - 4, py, x0 + 4, py,
                          fill=AXIS_COLOR, width=1)
            c.create_text(x0 - 8, py,
                          text=f"{y_val:.1f}",
                          font=("Segoe UI", 8),
                          fill=TEXT, anchor="e")

        # Ноль
        c.create_text(x0 - 8, cy + 12,
                      text="0", font=("Segoe UI", 8),
                      fill=TEXT, anchor="e")

        # ═══ Деления оси X ══════════════════════════════════════
        # Подписи времени каждые 0.5 с
        t_tick = math.ceil(t_start / 0.5) * 0.5
        while t_tick <= t_end:
            px = to_px(t_tick)
            c.create_line(px, cy - 4, px, cy + 4,
                          fill=AXIS_COLOR, width=1)
            c.create_text(px, cy + 16,
                          text=f"{t_tick:.1f}",
                          font=("Segoe UI", 7),
                          fill=MUTED)
            t_tick += 0.5

        # ═══ Колебание ══════════════════════════════════════════
        # Показываем 4 секунды, при 1000 точках — гладко
        points = []
        n_points = 1000
        for i in range(n_points + 1):
            t = t_start + (t_end - t_start) * i / n_points
            y = self.amp * math.sin(2 * math.pi * self.freq * t + self.phase)
            points.extend([to_px(t), to_py(y)])

        c.create_line(*points,
                      fill=WAVE_COLOR, width=3,
                      smooth=False, capstyle="round")

        # ═══ Текущая точка (правый край) ════════════════════════
        t_now = self.time
        y_now = self.amp * math.sin(2 * math.pi * self.freq * t_now + self.phase)
        px_now = to_px(t_now)
        py_now = to_py(y_now)

        c.create_oval(px_now - 6, py_now - 6,
                      px_now + 6, py_now + 6,
                      fill=POINT_COLOR, outline="white", width=2)

        # Подпись текущего значения
        c.create_text(px_now + 12, py_now - 12,
                      text=f"y = {y_now:.3f}",
                      font=("Consolas", 10, "bold"),
                      fill=WAVE_COLOR, anchor="w")

        # ═══ Параметры на графике ═══════════════════════════════
        c.create_text(x0 + 10, y0 + 8,
                      text=f"A = {self.amp:.2f}   f = {self.freq:.2f} Гц   "
                           f"φ = {self.phase:.2f} рад   "
                           f"T = {1/self.freq:.2f} с",
                      font=("Consolas", 10),
                      fill=MUTED, anchor="nw")

        # ═══ Значение y(t) ══════════════════════════════════════
        self.value_label.config(
            text=f"y(t) = {y_now:.3f}    ·    "
                 f"A = {self.amp:.2f}, f = {self.freq:.2f} Гц, "
                 f"φ = {self.phase:.2f} рад"
        )


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = HarmonicApp(root)
    root.mainloop()
