import tkinter as tk
import random


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

ACCENT = "#0a84ff"              # синий акцент
ACCENT_HOVER = "#0066cc"
ACCENT_PRESS = "#004c99"

BIT_ON = "#30d158"              # зелёный — 1
BIT_ON_HOVER = "#20a544"
BIT_OFF = "#e5e5ea"             # серый — 0
BIT_OFF_HOVER = "#d0d0d5"
BIT_TEXT_ON = "#ffffff"
BIT_TEXT_OFF = "#8a8a8e"


# ═══════════════════════════════════════════════════════════════════
# БИТ-ПЕРЕКЛЮЧАТЕЛЬ
# ═══════════════════════════════════════════════════════════════════
class BitSwitch:
    """Один бит — квадрат 48×48, нажатие меняет 0↔1."""
    def __init__(self, parent, index, on_change):
        self.index = index
        self.value = 0
        self.on_change = on_change

        self.btn = tk.Button(
            parent, text="0",
            font=("Consolas", 16, "bold"),
            bg=BIT_OFF, fg=BIT_TEXT_OFF,
            activebackground=BIT_OFF_HOVER,
            activeforeground=BIT_TEXT_OFF,
            bd=0, relief="flat",
            width=3, height=1,
            cursor="hand2",
            command=self.toggle,
        )

        # Hover
        self.btn.bind("<Enter>", self._on_enter)
        self.btn.bind("<Leave>", self._on_leave)

    def _on_enter(self, e):
        if self.value == 1:
            self.btn.config(bg=BIT_ON_HOVER)
        else:
            self.btn.config(bg=BIT_OFF_HOVER)

    def _on_leave(self, e):
        if self.value == 1:
            self.btn.config(bg=BIT_ON)
        else:
            self.btn.config(bg=BIT_OFF)

    def toggle(self):
        self.value = 1 - self.value
        self._refresh()
        self.on_change()

    def set(self, value):
        self.value = value
        self._refresh()

    def _refresh(self):
        if self.value == 1:
            self.btn.config(text="1", bg=BIT_ON, fg=BIT_TEXT_ON,
                            activebackground=BIT_ON_HOVER,
                            activeforeground=BIT_TEXT_ON)
        else:
            self.btn.config(text="0", bg=BIT_OFF, fg=BIT_TEXT_OFF,
                            activebackground=BIT_OFF_HOVER,
                            activeforeground=BIT_TEXT_OFF)


# ═══════════════════════════════════════════════════════════════════
# СТРОКА БАЙТА
# ═══════════════════════════════════════════════════════════════════
class ByteRow:
    """Один байт — 8 переключателей + его представления."""
    def __init__(self, parent, index, on_change):
        self.index = index
        self.on_change = on_change
        self.bits = []

        # Контейнер строки
        self.frame = tk.Frame(parent, bg=CARD)

        # ─── Метка байта ────────────────────────────────────
        tk.Label(self.frame, text=f"Байт {index + 1}",
                 font=("Segoe UI", 11, "bold"),
                 bg=CARD, fg=TEXT, width=8, anchor="w"
                 ).grid(row=0, column=0, padx=(0, 14), pady=6)

        # ─── 8 переключателей бит ───────────────────────────
        bits_frame = tk.Frame(self.frame, bg=CARD)
        bits_frame.grid(row=0, column=1, pady=6)

        for i in range(8):
            bit = BitSwitch(bits_frame, i, self._on_bit_change)
            bit.btn.pack(side="left", padx=2)
            self.bits.append(bit)

        # ─── Разделитель ────────────────────────────────────
        tk.Frame(self.frame, bg=BORDER, width=1
                 ).grid(row=0, column=2, padx=14, sticky="ns", pady=6)

        # ─── Двоичное представление ─────────────────────────
        self.binary_label = tk.Label(
            self.frame, text="00000000",
            font=("Consolas", 13, "bold"),
            bg=CARD, fg=TEXT, width=10, anchor="w"
        )
        self.binary_label.grid(row=0, column=3, padx=(0, 14), pady=6)

        # ─── DEC ────────────────────────────────────────────
        tk.Label(self.frame, text="DEC",
                 font=("Segoe UI", 7, "bold"),
                 bg=CARD, fg=MUTED).grid(row=0, column=4, padx=(0, 4))

        self.dec_label = tk.Label(
            self.frame, text="0",
            font=("Consolas", 12, "bold"),
            bg=CARD, fg=ACCENT, width=4, anchor="e"
        )
        self.dec_label.grid(row=0, column=5, padx=(0, 14), pady=6)

        # ─── HEX ────────────────────────────────────────────
        tk.Label(self.frame, text="HEX",
                 font=("Segoe UI", 7, "bold"),
                 bg=CARD, fg=MUTED).grid(row=0, column=6, padx=(0, 4))

        self.hex_label = tk.Label(
            self.frame, text="0x00",
            font=("Consolas", 12, "bold"),
            bg=CARD, fg=ACCENT, width=6, anchor="e"
        )
        self.hex_label.grid(row=0, column=7, padx=(0, 4), pady=6)

    def _on_bit_change(self):
        self._update_labels()
        if self.on_change:
            self.on_change()

    def get_value(self):
        """Возвращает значение байта (0…255)."""
        value = 0
        for i, bit in enumerate(self.bits):
            if bit.value == 1:
                value |= (1 << (7 - i))  # старший бит слева
        return value

    def set_value(self, value):
        """Устанавливает байт из числа 0…255."""
        value = value & 0xFF
        for i, bit in enumerate(self.bits):
            bit.set((value >> (7 - i)) & 1)
        self._update_labels()

    def _update_labels(self):
        val = self.get_value()
        self.binary_label.config(
            text="".join(str(b.value) for b in self.bits)
        )
        self.dec_label.config(text=str(val))
        self.hex_label.config(text=f"0x{val:02X}")


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class RandomBytesApp:
    def __init__(self, root):
        self.root = root
        root.title("Генератор 4 случайных байт")
        root.geometry("820x480")
        root.minsize(760, 460)
        root.configure(bg=BG)
        root.resizable(False, False)

        # ═══ Заголовок ═══════════════════════════════════════════
        tk.Label(root, text="Генератор случайных байт",
                 font=("Segoe UI", 18, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(20, 4))

        tk.Label(root,
                 text="32 бита · 4 байта · клик по биту меняет его вручную",
                 font=("Segoe UI", 10),
                 bg=BG, fg=MUTED).pack(pady=(0, 16))

        # ═══ Карточка с байтами ══════════════════════════════════
        card = tk.Frame(root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=30, pady=(0, 14), fill="x")

        # Шапка с пояснениями колонок
        head = tk.Frame(card, bg=CARD)
        head.pack(fill="x", padx=20, pady=(14, 6))

        tk.Label(head, text="",
                 bg=CARD, width=8).grid(row=0, column=0)
        tk.Label(head, text="БИТЫ  (7 … 0)",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED
                 ).grid(row=0, column=1, sticky="w", padx=(0, 14))
        tk.Label(head, text="",
                 bg=CARD, width=1).grid(row=0, column=2, padx=14)
        tk.Label(head, text="BIN",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED
                 ).grid(row=0, column=3, sticky="w", padx=(0, 14))
        tk.Label(head, text="",
                 bg=CARD, width=2).grid(row=0, column=4)
        tk.Label(head, text="",
                 bg=CARD, width=4).grid(row=0, column=5, padx=(0, 14))
        tk.Label(head, text="",
                 bg=CARD, width=2).grid(row=0, column=6)
        tk.Label(head, text="",
                 bg=CARD, width=6).grid(row=0, column=7)

        # Строки байт
        self.byte_rows = []
        for i in range(4):
            row = ByteRow(card, i, self.update_summary)
            row.frame.pack(fill="x", padx=20, pady=3)
            self.byte_rows.append(row)

        # Разделитель
        tk.Frame(card, bg=BORDER, height=1).pack(fill="x", padx=20, pady=(6, 0))

        # Итог
        summary_frame = tk.Frame(card, bg=CARD)
        summary_frame.pack(fill="x", padx=20, pady=(8, 16))

        tk.Label(summary_frame, text="ИТОГО:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=MUTED).pack(side="left")

        self.summary_label = tk.Label(
            summary_frame, text="0x00 0x00 0x00 0x00",
            font=("Consolas", 14, "bold"),
            bg=CARD, fg=ACCENT
        )
        self.summary_label.pack(side="left", padx=(12, 0))

        self.total_label = tk.Label(
            summary_frame, text="32 бита",
            font=("Consolas", 10),
            bg=CARD, fg=MUTED
        )
        self.total_label.pack(side="right")

        # ═══ Кнопки ══════════════════════════════════════════════
        btns = tk.Frame(root, bg=BG)
        btns.pack(pady=(0, 20))

        self.btn_generate = self._make_button(
            btns, "🎲  Сгенерировать", ACCENT,
            ACCENT_HOVER, ACCENT_PRESS, self.generate,
        )
        self.btn_generate.pack(side="left", padx=4)

        self._make_button(
            btns, "⇄  Инвертировать", "#8e44ad",
            "#7d3c98", "#6c3483", self.invert,
        ).pack(side="left", padx=4)

        self._make_button(
            btns, "🧹  Сбросить", "#ff9f0a",
            "#cc7f08", "#a36606", self.reset,
        ).pack(side="left", padx=4)

        # ═══ Клавиатура ══════════════════════════════════════════
        root.bind("<space>", lambda e: self.generate())
        root.bind("<Control-r>", lambda e: self.reset())
        root.bind("<Control-i>", lambda e: self.invert())

        # Первичная генерация
        self.generate()

    # ─── Кнопки ────────────────────────────────────────────────
    def _make_button(self, parent, text, bg, hover, press, command):
        btn = tk.Button(
            parent, text=text,
            font=("Segoe UI", 11, "bold"),
            bg=bg, fg="#ffffff",
            activebackground=press, activeforeground="#ffffff",
            bd=0, relief="flat",
            padx=20, pady=12, cursor="hand2",
            command=command,
        )

        def on_enter(e):
            btn.config(bg=hover)

        def on_leave(e):
            btn.config(bg=bg)

        def on_press(e):
            btn.config(bg=press)

        def on_release(e):
            btn.config(bg=hover)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        btn.bind("<ButtonPress-1>", on_press)
        btn.bind("<ButtonRelease-1>", on_release)
        return btn

    # ─── Действия ──────────────────────────────────────────────
    def generate(self):
        """Генерирует 4 случайных байта."""
        for row in self.byte_rows:
            row.set_value(random.randint(0, 255))
        self.update_summary()

    def reset(self):
        """Обнуляет все байты."""
        for row in self.byte_rows:
            row.set_value(0)
        self.update_summary()

    def invert(self):
        """Инвертирует все биты."""
        for row in self.byte_rows:
            for bit in row.bits:
                bit.set(1 - bit.value)
            row._update_labels()
        self.update_summary()

    def update_summary(self):
        """Обновляет итоговую строку."""
        values = [row.get_value() for row in self.byte_rows]
        hex_str = "  ".join(f"0x{v:02X}" for v in values)
        self.summary_label.config(text=hex_str)

        # Считаем единичные биты
        total_ones = sum(
            bin(v).count("1") for v in values
        )
        self.total_label.config(
            text=f"{total_ones} единиц из 32 бит"
        )


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = RandomBytesApp(root)
    root.mainloop()
