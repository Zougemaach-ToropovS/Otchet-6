import tkinter as tk
import random


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
CARD2 = "#fafafa"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
ACCENT_PRESS = "#004c99"

PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"
PURPLE_PRESS = "#6c3483"

ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
ORANGE_PRESS = "#a36606"

GREEN = "#30d158"
GREEN_HOVER = "#20a544"

BIT_ON = "#30d158"
BIT_ON_HOVER = "#20a544"
BIT_OFF = "#e5e5ea"
BIT_OFF_HOVER = "#d0d0d5"
BIT_TEXT_ON = "#ffffff"
BIT_TEXT_OFF = "#8a8a8e"

HEX_COLOR = "#8e44ad"          # фиолетовый для HEX
BIN_COLOR = "#0a84ff"          # синий для BIN
DEC_COLOR = "#ff9f0a"          # оранжевый для DEC


# ═══════════════════════════════════════════════════════════════════
# БИТ-ПЕРЕКЛЮЧАТЕЛЬ
# ═══════════════════════════════════════════════════════════════════
class BitSwitch:
    def __init__(self, parent, index, on_change):
        self.index = index
        self.value = 0
        self.on_change = on_change

        self.btn = tk.Button(
            parent, text="0",
            font=("Consolas", 14, "bold"),
            bg=BIT_OFF, fg=BIT_TEXT_OFF,
            activebackground=BIT_OFF_HOVER,
            activeforeground=BIT_TEXT_OFF,
            bd=0, relief="flat",
            width=3, height=1,
            cursor="hand2",
            command=self.toggle,
        )
        self.btn.bind("<Enter>", self._on_enter)
        self.btn.bind("<Leave>", self._on_leave)

    def _on_enter(self, e):
        if self.value == 1:
            self.btn.config(bg=BIT_ON_HOVER)
        else:
            self.btn.config(bg=BIT_OFF_HOVER)

    def _on_leave(self, e):
        if self.value == 1:
            self.btn.config(bg=BIT_ON)
        else:
            self.btn.config(bg=BIT_OFF)

    def toggle(self):
        self.value = 1 - self.value
        self._refresh()
        self.on_change()

    def set(self, value):
        self.value = value
        self._refresh()

    def _refresh(self):
        if self.value == 1:
            self.btn.config(text="1", bg=BIT_ON, fg=BIT_TEXT_ON,
                            activebackground=BIT_ON_HOVER,
                            activeforeground=BIT_TEXT_ON)
        else:
            self.btn.config(text="0", bg=BIT_OFF, fg=BIT_TEXT_OFF,
                            activebackground=BIT_OFF_HOVER,
                            activeforeground=BIT_TEXT_OFF)


# ═══════════════════════════════════════════════════════════════════
# СТРОКА БАЙТА
# ═══════════════════════════════════════════════════════════════════
class ByteRow:
    def __init__(self, parent, index, on_change):
        self.index = index
        self.on_change = on_change
        self.bits = []

        self.frame = tk.Frame(parent, bg=CARD)

        # ─── Метка байта ────────────────────────────────────
        tk.Label(self.frame, text=f"Байт {index + 1}",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT, width=7, anchor="w"
                 ).grid(row=0, column=0, padx=(0, 10), pady=6)

        # ─── 8 переключателей ───────────────────────────────
        bits_frame = tk.Frame(self.frame, bg=CARD)
        bits_frame.grid(row=0, column=1, pady=6)

        for i in range(8):
            bit = BitSwitch(bits_frame, i, self._on_bit_change)
            bit.btn.pack(side="left", padx=2)
            self.bits.append(bit)

        # ─── Разделители ────────────────────────────────────
        tk.Frame(self.frame, bg=BORDER, width=1
                 ).grid(row=0, column=2, padx=10, sticky="ns", pady=6)

        # ─── BIN ────────────────────────────────────────────
        bin_frame = tk.Frame(self.frame, bg=CARD)
        bin_frame.grid(row=0, column=3, padx=(0, 8), pady=6)

        tk.Label(bin_frame, text="BIN",
                 font=("Segoe UI", 7, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w")

        self.binary_label = tk.Label(
            bin_frame, text="00000000",
            font=("Consolas", 12, "bold"),
            bg=CARD, fg=BIN_COLOR
        )
        self.binary_label.pack()

        # ─── DEC ────────────────────────────────────────────
        dec_frame = tk.Frame(self.frame, bg=CARD)
        dec_frame.grid(row=0, column=4, padx=(0, 8), pady=6)

        tk.Label(dec_frame, text="DEC",
                 font=("Segoe UI", 7, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w")

        self.dec_label = tk.Label(
            dec_frame, text="0",
            font=("Consolas", 12, "bold"),
            bg=CARD, fg=DEC_COLOR, width=4
        )
        self.dec_label.pack()

        # ─── HEX ────────────────────────────────────────────
        hex_frame = tk.Frame(self.frame, bg=CARD)
        hex_frame.grid(row=0, column=5, padx=(0, 0), pady=6)

        tk.Label(hex_frame, text="HEX",
                 font=("Segoe UI", 7, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w")

        self.hex_label = tk.Label(
            hex_frame, text="0x00",
            font=("Consolas", 12, "bold"),
            bg=CARD, fg=HEX_COLOR, width=5
        )
        self.hex_label.pack()

    def _on_bit_change(self):
        self._update_labels()
        if self.on_change:
            self.on_change()

    def get_value(self):
        value = 0
        for i, bit in enumerate(self.bits):
            if bit.value == 1:
                value |= (1 << (7 - i))
        return value

    def set_value(self, value):
        value = value & 0xFF
        for i, bit in enumerate(self.bits):
            bit.set((value >> (7 - i)) & 1)
        self._update_labels()

    def _update_labels(self):
        val = self.get_value()
        self.binary_label.config(text="".join(str(b.value) for b in self.bits))
        self.dec_label.config(text=str(val))
        self.hex_label.config(text=f"0x{val:02X}")


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class RandomBytesApp:
    def __init__(self, root):
        self.root = root
        root.title("Генератор 4 байт — HEX, BIN, DEC")
        root.geometry("880x680")
        root.minsize(820, 640)
        root.configure(bg=BG)
        root.resizable(False, False)

        # ═══ Заголовок ═══════════════════════════════════════════
        tk.Label(root, text="Генератор 4 случайных байт",
                 font=("Segoe UI", 18, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(18, 4))

        tk.Label(root,
                 text="32 бита · HEX · BIN · DEC — клик по биту меняет его",
                 font=("Segoe UI", 10),
                 bg=BG, fg=MUTED).pack(pady=(0, 14))

        # ═══ Карточка с байтами ══════════════════════════════════
        card = tk.Frame(root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=30, pady=(0, 12), fill="x")

        # Строки байт
        self.byte_rows = []
        for i in range(4):
            row = ByteRow(card, i, self.update_summary)
            row.frame.pack(fill="x", padx=20, pady=3)
            self.byte_rows.append(row)

        tk.Frame(card, bg=BORDER, height=1).pack(fill="x", padx=20, pady=(8, 0))

        # ═══ Блок HEX — итог ═════════════════════════════════════
        hex_card = tk.Frame(root, bg=CARD,
                            highlightthickness=1,
                            highlightbackground=BORDER)
        hex_card.pack(padx=30, pady=(0, 12), fill="x")

        tk.Label(hex_card, text="ШЕСТНАДЦАТЕРИЧНОЕ ПРЕДСТАВЛЕНИЕ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED).pack(anchor="w", padx=20, pady=(14, 4))

        # Строка 1: 0xB5 0x3A 0x8C 0x01
        row1 = tk.Frame(hex_card, bg=CARD)
        row1.pack(fill="x", padx=20, pady=(0, 4))

        tk.Label(row1, text="По байтам:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=MUTED, width=12, anchor="w"
                 ).pack(side="left")

        self.hex_bytes_label = tk.Label(
            row1, text="0x00  0x00  0x00  0x00",
            font=("Consolas", 18, "bold"),
            bg=CARD, fg=HEX_COLOR, anchor="w"
        )
        self.hex_bytes_label.pack(side="left")

        # Строка 2: 0xB53A8C01
        row2 = tk.Frame(hex_card, bg=CARD)
        row2.pack(fill="x", padx=20, pady=(0, 4))

        tk.Label(row2, text="Слитно:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=MUTED, width=12, anchor="w"
                 ).pack(side="left")

        self.hex_full_label = tk.Label(
            row2, text="0x00000000",
            font=("Consolas", 18, "bold"),
            bg=CARD, fg=HEX_COLOR, anchor="w"
        )
        self.hex_full_label.pack(side="left")

        # Строка 3: без префикса
        row3 = tk.Frame(hex_card, bg=CARD)
        row3.pack(fill="x", padx=20, pady=(0, 4))

        tk.Label(row3, text="Без 0x:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=MUTED, width=12, anchor="w"
                 ).pack(side="left")

        self.hex_plain_label = tk.Label(
            row3, text="00 00 00 00",
            font=("Consolas", 14),
            bg=CARD, fg=MUTED, anchor="w"
        )
        self.hex_plain_label.pack(side="left")

        # Строка 4: BIN слитно
        row4 = tk.Frame(hex_card, bg=CARD)
        row4.pack(fill="x", padx=20, pady=(0, 16))

        tk.Label(row4, text="BIN слитно:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=MUTED, width=12, anchor="w"
                 ).pack(side="left")

        self.bin_full_label = tk.Label(
            row4, text="00000000 00000000 00000000 00000000",
            font=("Consolas", 11),
            bg=CARD, fg=BIN_COLOR, anchor="w"
        )
        self.bin_full_label.pack(side="left")

        # ═══ Побитовые операции в HEX ════════════════════════════
        ops_card = tk.Frame(root, bg=CARD,
                            highlightthickness=1,
                            highlightbackground=BORDER)
        ops_card.pack(padx=30, pady=(0, 12), fill="x")

        tk.Label(ops_card, text="ПОБИТОВЫЕ ОПЕРАЦИИ (результат в HEX)",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED
                 ).pack(anchor="w", padx=20, pady=(12, 4))

        ops_row = tk.Frame(ops_card, bg=CARD)
        ops_row.pack(fill="x", padx=20, pady=(0, 12))

        for op_name, op_func in [
            ("AND  &", lambda a: a[0] & a[1] & a[2] & a[3]),
            ("OR  |",  lambda a: a[0] | a[1] | a[2] | a[3]),
            ("XOR  ^", lambda a: a[0] ^ a[1] ^ a[2] ^ a[3]),
            ("NOT  ~", lambda a: (~a[0]) & 0xFF),
        ]:
            frame = tk.Frame(ops_row, bg=CARD)
            frame.pack(side="left", padx=(0, 20))

            tk.Label(frame, text=op_name,
                     font=("Segoe UI", 9, "bold"),
                     bg=CARD, fg=MUTED).pack(anchor="w")

            lbl = tk.Label(frame, text="0x00",
                           font=("Consolas", 12, "bold"),
                           bg=CARD, fg=ACCENT, width=6)
            lbl.pack()

            # Сохраняем ссылку для обновления
            self.__dict__[f"op_{op_name.split()[0]}"] = {
                "label": lbl, "func": op_func,
            }

        # ═══ Кнопки ══════════════════════════════════════════════
        btns = tk.Frame(root, bg=BG)
        btns.pack(pady=(0, 20))

        self._make_button(btns, "🎲  Сгенерировать",
                          ACCENT, ACCENT_HOVER, ACCENT_PRESS,
                          self.generate).pack(side="left", padx=4)

        self._make_button(btns, "⇄  Инвертировать",
                          PURPLE, PURPLE_HOVER, PURPLE_PRESS,
                          self.invert).pack(side="left", padx=4)

        self._make_button(btns, "🧹  Сбросить",
                          ORANGE, ORANGE_HOVER, ORANGE_PRESS,
                          self.reset).pack(side="left", padx=4)

        self._make_button(btns, "📋  Копировать HEX",
                          GREEN, GREEN_HOVER, "#187a33",
                          self.copy_hex).pack(side="left", padx=4)

        # ═══ Клавиатура ══════════════════════════════════════════
        root.bind("<space>", lambda e: self.generate())
        root.bind("<Control-r>", lambda e: self.reset())
        root.bind("<Control-i>", lambda e: self.invert())
        root.bind("<Control-c>", lambda e: self.copy_hex())

        # ═══ Статус ══════════════════════════════════════════════
        self.status = tk.Label(root, text="",
                               font=("Segoe UI", 9),
                               bg=BG, fg=MUTED)
        self.status.pack(side="bottom", pady=(0, 12))

        # Первичная генерация
        self.generate()

    # ─── Кнопки ────────────────────────────────────────────────
    def _make_button(self, parent, text, bg, hover, press, command):
        btn = tk.Button(
            parent, text=text,
            font=("Segoe UI", 10, "bold"),
            bg=bg, fg="#ffffff",
            activebackground=press, activeforeground="#ffffff",
            bd=0, relief="flat",
            padx=16, pady=10, cursor="hand2",
            command=command,
        )

        btn.bind("<Enter>", lambda e: btn.config(bg=hover))
        btn.bind("<Leave>", lambda e: btn.config(bg=bg))
        btn.bind("<ButtonPress-1>", lambda e: btn.config(bg=press))
        btn.bind("<ButtonRelease-1>", lambda e: btn.config(bg=hover))
        return btn

    # ─── Действия ──────────────────────────────────────────────
    def generate(self):
        for row in self.byte_rows:
            row.set_value(random.randint(0, 255))
        self.update_summary()
        self.status.config(text="Сгенерированы новые 4 байта", fg=ACCENT)

    def reset(self):
        for row in self.byte_rows:
            row.set_value(0)
        self.update_summary()
        self.status.config(text="Все байты обнулены", fg=MUTED)

    def invert(self):
        for row in self.byte_rows:
            for bit in row.bits:
                bit.set(1 - bit.value)
            row._update_labels()
        self.update_summary()
        self.status.config(text="Все 32 бита инвертированы", fg=PURPLE)

    def copy_hex(self):
        values = [row.get_value() for row in self.byte_rows]
        hex_str = " ".join(f"0x{v:02X}" for v in values)
        self.root.clipboard_clear()
        self.root.clipboard_append(hex_str)
        self.status.config(text=f"Скопировано: {hex_str}", fg=GREEN)

    # ─── Обновление итогов ─────────────────────────────────────
    def update_summary(self):
        values = [row.get_value() for row in self.byte_rows]

        # По байтам: 0xB5  0x3A  0x8C  0x01
        hex_bytes = "  ".join(f"0x{v:02X}" for v in values)
        self.hex_bytes_label.config(text=hex_bytes)

        # Слитно: 0xB53A8C01
        hex_full = "0x" + "".join(f"{v:02X}" for v in values)
        self.hex_full_label.config(text=hex_full)

        # Без префикса: B5 3A 8C 01
        hex_plain = " ".join(f"{v:02X}" for v in values)
        self.hex_plain_label.config(text=hex_plain)

        # BIN слитно: 10110101 00111010 ...
        bin_full = " ".join(f"{v:08b}" for v in values)
        self.bin_full_label.config(text=bin_full)

        # Побитовые операции
        for key in ("op_AND", "op_OR", "op_XOR", "op_NOT"):
            info = self.__dict__.get(key)
            if info:
                result = info["func"](values)
                info["label"].config(text=f"0x{result:02X}")


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = RandomBytesApp(root)
    root.mainloop()
