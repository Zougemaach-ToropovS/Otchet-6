import tkinter as tk
import math


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

SIGNAL_COLOR = "#1e5fff"     # синяя линия
ENVELOPE_COLOR = "#e53935"   # красный пунктир
AXIS_COLOR = "#000000"
GRID_COLOR = "#ececf0"
ZERO_LINE = "#c0c0c0"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class AMApp:
    def __init__(self, root):
        self.root = root
        root.title("Амплитудная модуляция")
        root.geometry("1200x900")
        root.minsize(1100, 860)
        root.configure(bg=BG)
        root.resizable(False, False)

        # Параметры
        self.fc = 10.0        # несущая, Гц
        self.fm = 1.0         # модулирующая, Гц
        self.A = 1.0          # амплитуда
        self.depth = 50       # глубина, %

        # ─── Заголовок ─────────────────────────────────────────
        tk.Label(root, text="Амплитудная модуляция (AM)",
                 font=("Segoe UI", 16, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(14, 3))

        self.formula = tk.Label(
            root,
            text="u(t) = A · [1 + m · sin(2π · f_m · t)] · sin(2π · f_c · t)",
            font=("Consolas", 11),
            bg=BG, fg=ACCENT)
        self.formula.pack(pady=(0, 10))

        # ─── Главный график ────────────────────────────────────
        card = tk.Frame(root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=24, pady=(0, 10))

        self.canvas = tk.Canvas(card, width=1150, height=340,
                                bg="white", highlightthickness=0)
        self.canvas.pack(padx=15, pady=15)

        # ─── Значения ──────────────────────────────────────────
        info = tk.Frame(root, bg=BG)
        info.pack(pady=(0, 10))

        self.info_label = tk.Label(info, text="",
                                   font=("Consolas", 11),
                                   bg=BG, fg=TEXT)
        self.info_label.pack()

        # ─── Ползунки ──────────────────────────────────────────
        ctrl = tk.Frame(root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        ctrl.pack(padx=24, pady=(0, 10), fill="x")

        # Ряд 1
        row1 = tk.Frame(ctrl, bg=CARD)
        row1.pack(fill="x", padx=16, pady=(12, 6))

        self.fc_scale, self.fc_lbl = self._slider(
            row1, "Несущая частота f_c", "Гц",
            1, 20, 10, 0.5, self._set_fc, SIGNAL_COLOR)

        self.fm_scale, self.fm_lbl = self._slider(
            row1, "Модулирующая f_m", "Гц",
            0.1, 3.0, 1.0, 0.1, self._set_fm, ENVELOPE_COLOR)

        # Ряд 2
        row2 = tk.Frame(ctrl, bg=CARD)
        row2.pack(fill="x", padx=16, pady=(0, 12))

        self.A_scale, self.A_lbl = self._slider(
            row2, "Амплитуда A", "",
            0.1, 1.5, 1.0, 0.05, self._set_A, PURPLE)

        self.m_scale, self.m_lbl = self._slider(
            row2, "Глубина модуляции m", "%",
            0, 150, 50, 5, self._set_depth, ORANGE)

        # ─── Кнопки пресетов ───────────────────────────────────
        btns = tk.Frame(root, bg=BG)
        btns.pack(pady=(0, 10))

        tk.Label(btns, text="Глубина:", font=("Segoe UI", 10, "bold"),
                 bg=BG, fg=MUTED).pack(side="left", padx=(0, 10))

        self._make_button(btns, "50%", GREEN, GREEN_HOVER,
                          lambda: self.set_depth(50)).pack(side="left", padx=4)
        self._make_button(btns, "100%", ORANGE, ORANGE_HOVER,
                          lambda: self.set_depth(100)).pack(side="left", padx=4)
        self._make_button(btns, "150% (перемодуляция)", "#e53935", "#c62828",
                          lambda: self.set_depth(150)).pack(side="left", padx=4)

        # ─── Мини-превью 3 графиков ────────────────────────────
        tk.Label(root, text="Сравнение: глубина 50%, 100%, 150%",
                 font=("Segoe UI", 10, "bold"),
                 bg=BG, fg=MUTED).pack(pady=(8, 4))

        preview_card = tk.Frame(root, bg=CARD,
                                highlightthickness=1,
                                highlightbackground=BORDER)
        preview_card.pack(padx=24, pady=(0, 16))

        self.preview_canvas = tk.Canvas(preview_card,
                                        width=1150, height=260,
                                        bg="white", highlightthickness=0)
        self.preview_canvas.pack(padx=15, pady=15)

        # Первичная отрисовка
        self.redraw()
        self.redraw_preview()

    # ─── Ползунок ───────────────────────────────────────────────
    def _slider(self, parent, label, unit, vmin, vmax, initial,
                step, callback, color):
        frame = tk.Frame(parent, bg=CARD)
        frame.pack(side="left", fill="x", expand=True, padx=(0, 16))

        header = tk.Frame(frame, bg=CARD)
        header.pack(fill="x")

        tk.Label(header, text=label,
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED).pack(side="left")

        value_lbl = tk.Label(header,
                             text=f"{initial:g} {unit}".strip(),
                             font=("Consolas", 11, "bold"),
                             bg=CARD, fg=color)
        value_lbl.pack(side="right")

        def on_move(v):
            val = float(v)
            callback(val)
            if unit:
                if unit == "%":
                    value_lbl.config(text=f"{int(val)} %")
                elif unit == "Гц":
                    value_lbl.config(text=f"{val:.1f} Гц")
                else:
                    value_lbl.config(text=f"{val:g} {unit}")
            else:
                value_lbl.config(text=f"{val:.2f}")
            self.redraw()
            self.redraw_preview()

        scale = tk.Scale(
            frame, from_=vmin, to=vmax, resolution=step,
            orient="horizontal", showvalue=False,
            bg=CARD, fg=TEXT, troughcolor="#ececf0",
            activebackground=color,
            highlightthickness=0, bd=0,
            sliderlength=18, width=8,
            command=on_move,
        )
        scale.set(initial)
        scale.pack(fill="x", pady=(4, 0))

        return scale, value_lbl

    def _make_button(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="#ffffff",
                        activebackground=hover, activeforeground="#ffffff",
                        bd=0, padx=16, pady=8, cursor="hand2",
                        command=command)

        def on_enter(e): btn.config(bg=hover)

        def on_leave(e): btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn

    # ─── Обработчики параметров ─────────────────────────────────
    def _set_fc(self, v):
        self.fc = v

    def _set_fm(self, v):
        self.fm = v

    def _set_A(self, v):
        self.A = v

    def _set_depth(self, v):
        self.depth = v

    def set_depth(self, value):
        self.depth = value
        self.m_scale.set(value)

    # ─── Отрисовка главного графика ─────────────────────────────
    def redraw(self):
        c = self.canvas
        c.delete("all")

        W = 1150
        H = 340
        x0, x1 = 70, W - 30
        y0, y1 = 30, H - 40

        # Время — 2 секунды
        t_max = 2.0

        # Амплитуда: с учётом глубины — может превышать A при m > 1
        m = self.depth / 100.0
        y_max = self.A * (1 + m) * 1.15

        def to_px(t):
            return x0 + (t / t_max) * (x1 - x0)

        def to_py(y):
            return (y0 + y1) / 2 - (y / y_max) * (y1 - y0) / 2

        # ─── Сетка ────────────────────────────────────────────
        for i in range(9):
            t = t_max * i / 8
            px = to_px(t)
            c.create_line(px, y0, px, y1, fill=GRID_COLOR)

        # Горизонтальная сетка
        for i in range(-4, 5):
            y_val = y_max * i / 4
            py = to_py(y_val)
            c.create_line(x0, py, x1, py, fill=GRID_COLOR)

        # ─── Нулевая линия ────────────────────────────────────
        cy = to_py(0)
        c.create_line(x0, cy, x1, cy, fill=ZERO_LINE, width=1)

        # ─── Оси ──────────────────────────────────────────────
        c.create_line(x0 - 15, cy, x1 + 15, cy,
                      fill=AXIS_COLOR, width=1,
                      arrow="last", arrowshape=(10, 12, 4))
        c.create_line(x0, y1 + 10, x0, y0 - 10,
                      fill=AXIS_COLOR, width=1,
                      arrow="last", arrowshape=(10, 12, 4))

        c.create_text(x1 + 20, cy + 14, text="Время",
                      font=("Segoe UI", 10, "italic"), fill=TEXT)
        c.create_text(x0 - 14, y0 - 20, text="Амплитуда",
                      font=("Segoe UI", 10, "italic"), fill=TEXT)

        # Деления оси X
        for i in range(9):
            t = t_max * i / 8
            px = to_px(t)
            c.create_line(px, cy - 4, px, cy + 4,
                          fill=AXIS_COLOR, width=1)
            c.create_text(px, cy + 16,
                          text=f"{t:.1f}",
                          font=("Segoe UI", 7),
                          fill=MUTED)

        # Деления оси Y
        for i in range(-4, 5):
            y_val = y_max * i / 4
            py = to_py(y_val)
            c.create_line(x0 - 4, py, x0 + 4, py,
                          fill=AXIS_COLOR, width=1)
            c.create_text(x0 - 8, py,
                          text=f"{y_val:.1f}",
                          font=("Segoe UI", 7),
                          fill=TEXT, anchor="e")

        # ─── AM-сигнал ────────────────────────────────────────
        n_points = 2000
        signal_pts = []
        envelope_up = []
        envelope_down = []

        for i in range(n_points + 1):
            t = t_max * i / n_points
            # Огибающая
            env = self.A * (1 + m * math.sin(2 * math.pi * self.fm * t))
            # AM-сигнал
            u = env * math.sin(2 * math.pi * self.fc * t)

            signal_pts.extend([to_px(t), to_py(u)])
            envelope_up.extend([to_px(t), to_py(env)])
            envelope_down.extend([to_px(t), to_py(-env)])

        # Огибающая — красный пунктир
        c.create_line(*envelope_up,
                      fill=ENVELOPE_COLOR, width=2,
                      dash=(6, 4))
        c.create_line(*envelope_down,
                      fill=ENVELOPE_COLOR, width=2,
                      dash=(6, 4))

        # Сигнал — синяя линия
        c.create_line(*signal_pts,
                      fill=SIGNAL_COLOR, width=2)

        # ─── Легенда ──────────────────────────────────────────
        c.create_line(x0 + 10, y0 + 15, x0 + 40, y0 + 15,
                      fill=SIGNAL_COLOR, width=3)
        c.create_text(x0 + 46, y0 + 15, text="u(t) — AM-сигнал",
                      font=("Segoe UI", 9),
                      fill=TEXT, anchor="w")

        c.create_line(x0 + 10, y0 + 35, x0 + 40, y0 + 35,
                      fill=ENVELOPE_COLOR, width=2, dash=(6, 4))
        c.create_text(x0 + 46, y0 + 35,
                      text="Огибающая ±A·(1 + m·sin)",
                      font=("Segoe UI", 9),
                      fill=TEXT, anchor="w")

        # ─── Подписи параметров ────────────────────────────────
        c.create_text(x1 - 10, y0 + 15,
                      text=f"f_c = {self.fc:.1f} Гц    "
                           f"f_m = {self.fm:.1f} Гц    "
                           f"m = {self.depth}%",
                      font=("Consolas", 9),
                      fill=MUTED, anchor="e")

        # Инфо
        self.info_label.config(
            text=f"Несущая: {self.fc:.1f} Гц  ·  "
                 f"Модулирующая: {self.fm:.1f} Гц  ·  "
                 f"Амплитуда: {self.A:.2f}  ·  "
                 f"Глубина: {self.depth}%"
                 f"{' (перемодуляция!)' if self.depth > 100 else ''}"
        )

    # ─── Отрисовка трёх превью ─────────────────────────────────
    def redraw_preview(self):
        c = self.preview_canvas
        c.delete("all")

        W = 1150
        H = 260

        # Три колонки
        col_w = W // 3
        depths = [50, 100, 150]
        titles = ["m = 50%", "m = 100%", "m = 150% (перемодуляция)"]
        colors = [GREEN, ORANGE, "#e53935"]

        for idx, (m_pct, title, color) in enumerate(zip(depths, titles, colors)):
            x0 = idx * col_w + 20
            x1 = (idx + 1) * col_w - 20
            y0 = 35
            y1 = H - 25

            # Заголовок
            c.create_text((x0 + x1) / 2, 18,
                          text=title,
                          font=("Segoe UI", 10, "bold"),
                          fill=color)

            # Оси
            cy = (y0 + y1) / 2
            c.create_line(x0, cy, x1, cy, fill=ZERO_LINE, width=1)

            # Параметры
            t_max = 2.0
            fm = self.fm
            fc = self.fc
            A = self.A
            m = m_pct / 100.0
            y_max = A * (1 + m) * 1.05

            def to_px(t):
                return x0 + (t / t_max) * (x1 - x0)

            def to_py(y):
                return cy - (y / y_max) * (y1 - y0) / 2

            # Сигнал
            signal_pts = []
            env_up = []
            env_down = []
            n = 800
            for i in range(n + 1):
                t = t_max * i / n
                env = A * (1 + m * math.sin(2 * math.pi * fm * t))
                u = env * math.sin(2 * math.pi * fc * t)
                signal_pts.extend([to_px(t), to_py(u)])
                env_up.extend([to_px(t), to_py(env)])
                env_down.extend([to_px(t), to_py(-env)])

            c.create_line(*env_up,
                          fill=ENVELOPE_COLOR, width=1, dash=(4, 3))
            c.create_line(*env_down,
                          fill=ENVELOPE_COLOR, width=1, dash=(4, 3))
            c.create_line(*signal_pts,
                          fill=SIGNAL_COLOR, width=1)

            # Подпись оси
            c.create_text(x1 - 5, y1 - 5, text="Время",
                          font=("Segoe UI", 7, "italic"),
                          fill=MUTED, anchor="e")


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = AMApp(root)
    root.mainloop()
