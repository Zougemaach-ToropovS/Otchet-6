import tkinter as tk
import math
import random


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

AXIS_COLOR = "#000000"
GRID_COLOR = "#ececf0"

# Цвета 5 колебаний
COLORS = [
    "#e53935",   # красный
    "#fb8c00",   # оранжевый
    "#fdd835",   # жёлтый
    "#43a047",   # зелёный
    "#1e88e5",   # синий
]
SUM_COLOR = "#8e44ad"      # фиолетовый — сумма

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class HarmonicsApp:
    def __init__(self, root):
        self.root = root
        root.title("Сложение 5 гармонических колебаний")
        root.geometry("1240x900")
        root.minsize(1140, 860)
        root.configure(bg=BG)
        root.resizable(False, False)

        # Параметры 5 колебаний
        self.params = [
            {"amp": 1.0, "freq": 1.0, "on": True},
            {"amp": 0.5, "freq": 2.0, "on": True},
            {"amp": 0.3, "freq": 3.0, "on": True},
            {"amp": 0.2, "freq": 5.0, "on": True},
            {"amp": 0.15, "freq": 7.0, "on": True},
        ]

        # ═══ Заголовок ═══════════════════════════════════════════
        tk.Label(root, text="Сложение 5 гармонических колебаний",
                 font=("Segoe UI", 16, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(12, 3))

        tk.Label(root,
                 text="y(t) = Σ Aᵢ · sin(2π · fᵢ · t)    i = 1…5",
                 font=("Consolas", 11),
                 bg=BG, fg=ACCENT).pack(pady=(0, 10))

        # ═══ Карточка с графиком ═════════════════════════════════
        card = tk.Frame(root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=20, pady=(0, 10))

        self.canvas = tk.Canvas(card, width=1200, height=380,
                                bg="white", highlightthickness=0)
        self.canvas.pack(padx=15, pady=15)

        # ═══ Легенда ═════════════════════════════════════════════
        legend = tk.Frame(root, bg=BG)
        legend.pack(pady=(0, 8))

        for i, color in enumerate(COLORS):
            item = tk.Frame(legend, bg=BG)
            item.pack(side="left", padx=8)

            tk.Label(item, text="━", font=("Segoe UI", 14, "bold"),
                     bg=BG, fg=color).pack(side="left")

            tk.Label(item, text=f"y{i+1}",
                     font=("Segoe UI", 9, "bold"),
                     bg=BG, fg=TEXT).pack(side="left", padx=(2, 0))

        # Сумма в легенде
        sum_item = tk.Frame(legend, bg=BG)
        sum_item.pack(side="left", padx=(20, 8))

        tk.Label(sum_item, text="━━",
                 font=("Segoe UI", 14, "bold"),
                 bg=BG, fg=SUM_COLOR).pack(side="left")

        tk.Label(sum_item, text="Сумма",
                 font=("Segoe UI", 9, "bold"),
                 bg=BG, fg=SUM_COLOR).pack(side="left", padx=(2, 0))

        # ═══ Панель управления ═══════════════════════════════════
        ctrl = tk.Frame(root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        ctrl.pack(padx=20, pady=(0, 12), fill="x")

        # Заголовки колонок
        header = tk.Frame(ctrl, bg=CARD)
        header.pack(fill="x", padx=16, pady=(12, 4))

        for i in range(5):
            col = tk.Frame(header, bg=CARD)
            col.pack(side="left", padx=2, fill="x", expand=True)

            tk.Label(col, text=f"Колебание {i+1}",
                     font=("Segoe UI", 9, "bold"),
                     bg=CARD, fg=COLORS[i]).pack()

        # ─── Амплитуды ──────────────────────────────────────
        tk.Label(ctrl, text="АМПЛИТУДА",
                 font=("Segoe UI", 8, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(anchor="w", padx=16, pady=(8, 2))

        amp_row = tk.Frame(ctrl, bg=CARD)
        amp_row.pack(fill="x", padx=16)

        self.amp_scales = []
        self.amp_labels = []
        for i in range(5):
            col = tk.Frame(amp_row, bg=CARD)
            col.pack(side="left", padx=2, fill="x", expand=True)

            val_lbl = tk.Label(col, text="1.00",
                               font=("Consolas", 10, "bold"),
                               bg=CARD, fg=COLORS[i])
            val_lbl.pack()

            scale = tk.Scale(
                col, from_=0.0, to=2.0, resolution=0.05,
                orient="horizontal", showvalue=False,
                bg=CARD, fg=TEXT, troughcolor="#ececf0",
                activebackground=COLORS[i],
                highlightthickness=0, bd=0,
                sliderlength=16, width=8,
                command=lambda v, idx=i: self._set_amp(idx, float(v)),
            )
            scale.set(self.params[i]["amp"])
            scale.pack(fill="x")

            self.amp_scales.append(scale)
            self.amp_labels.append(val_lbl)

        # ─── Частоты ────────────────────────────────────────
        tk.Label(ctrl, text="ЧАСТОТА",
                 font=("Segoe UI", 8, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(anchor="w", padx=16, pady=(8, 2))

        freq_row = tk.Frame(ctrl, bg=CARD)
        freq_row.pack(fill="x", padx=16)

        self.freq_scales = []
        self.freq_labels = []
        for i in range(5):
            col = tk.Frame(freq_row, bg=CARD)
            col.pack(side="left", padx=2, fill="x", expand=True)

            val_lbl = tk.Label(col, text=f"{self.params[i]['freq']:g} Гц",
                               font=("Consolas", 10, "bold"),
                               bg=CARD, fg=COLORS[i])
            val_lbl.pack()

            scale = tk.Scale(
                col, from_=0.5, to=10.0, resolution=0.1,
                orient="horizontal", showvalue=False,
                bg=CARD, fg=TEXT, troughcolor="#ececf0",
                activebackground=COLORS[i],
                highlightthickness=0, bd=0,
                sliderlength=16, width=8,
                command=lambda v, idx=i: self._set_freq(idx, float(v)),
            )
            scale.set(self.params[i]["freq"])
            scale.pack(fill="x")

            self.freq_scales.append(scale)
            self.freq_labels.append(val_lbl)

        # ─── Включение/выключение ───────────────────────────
        toggle_row = tk.Frame(ctrl, bg=CARD)
        toggle_row.pack(fill="x", padx=16, pady=(8, 12))

        self.toggles = []
        for i in range(5):
            col = tk.Frame(toggle_row, bg=CARD)
            col.pack(side="left", padx=2, fill="x", expand=True)

            var = tk.BooleanVar(value=True)
            cb = tk.Checkbutton(
                col, text="включено",
                variable=var,
                font=("Segoe UI", 9),
                bg=CARD, fg=COLORS[i],
                activebackground=CARD, activeforeground=COLORS[i],
                selectcolor=CARD,
                bd=0, highlightthickness=0, cursor="hand2",
                command=lambda idx=i: self._toggle(idx),
            )
            cb.pack()

            self.toggles.append(var)

        # ═══ Кнопки ══════════════════════════════════════════════
        btns = tk.Frame(root, bg=BG)
        btns.pack(pady=(0, 16))

        self._make_button(btns, "🎲  Случайно",
                          ACCENT, ACCENT_HOVER, "#004c99",
                          self.randomize).pack(side="left", padx=4)

        self._make_button(btns, "🔲  Меандр",
                          GREEN, GREEN_HOVER, "#187a33",
                          self.example_meander).pack(side="left", padx=4)

        self._make_button(btns, "◺  Пила",
                          ORANGE, ORANGE_HOVER, "#a36606",
                          self.example_saw).pack(side="left", padx=4)

        self._make_button(btns, "↻  Сброс",
                          "#8e44ad", "#7d3c98", "#6c3483",
                          self.reset).pack(side="left", padx=4)

        # Первичная отрисовка
        self.redraw()

    # ─── Кнопки ────────────────────────────────────────────────
    def _make_button(self, parent, text, bg, hover, press, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="#ffffff",
                        activebackground=press, activeforeground="#ffffff",
                        bd=0, relief="flat",
                        padx=18, pady=10, cursor="hand2",
                        command=command)
        btn.bind("<Enter>", lambda e: btn.config(bg=hover))
        btn.bind("<Leave>", lambda e: btn.config(bg=bg))
        btn.bind("<ButtonPress-1>", lambda e: btn.config(bg=press))
        btn.bind("<ButtonRelease-1>", lambda e: btn.config(bg=hover))
        return btn

    # ─── Обработчики ───────────────────────────────────────────
    def _set_amp(self, idx, value):
        self.params[idx]["amp"] = value
        self.amp_labels[idx].config(text=f"{value:.2f}")
        self.redraw()

    def _set_freq(self, idx, value):
        self.params[idx]["freq"] = value
        self.freq_labels[idx].config(text=f"{value:g} Гц")
        self.redraw()

    def _toggle(self, idx):
        self.params[idx]["on"] = self.toggles[idx].get()
        self.redraw()

    # ─── Примеры ───────────────────────────────────────────────
    def randomize(self):
        for i in range(5):
            self.params[i]["amp"] = random.uniform(0.1, 1.5)
            self.params[i]["freq"] = random.uniform(0.5, 8.0)
            self.params[i]["on"] = True
            self.amp_scales[i].set(self.params[i]["amp"])
            self.freq_scales[i].set(self.params[i]["freq"])
            self.toggles[i].set(True)
            self.amp_labels[i].config(text=f"{self.params[i]['amp']:.2f}")
            self.freq_labels[i].config(text=f"{self.params[i]['freq']:.1f} Гц")
        self.redraw()

    def example_meander(self):
        """Приближение меандра — нечётные гармоники."""
        amps = [1.0, 0.0, 0.33, 0.0, 0.2]
        freqs = [1.0, 2.0, 3.0, 4.0, 5.0]
        for i in range(5):
            self.params[i]["amp"] = amps[i]
            self.params[i]["freq"] = freqs[i]
            self.params[i]["on"] = True
            self.amp_scales[i].set(amps[i])
            self.freq_scales[i].set(freqs[i])
            self.toggles[i].set(True)
            self.amp_labels[i].config(text=f"{amps[i]:.2f}")
            self.freq_labels[i].config(text=f"{freqs[i]:g} Гц")
        self.redraw()

    def example_saw(self):
        """Приближение пилы — все гармоники."""
        amps = [1.0, 0.5, 0.33, 0.25, 0.2]
        freqs = [1.0, 2.0, 3.0, 4.0, 5.0]
        for i in range(5):
            self.params[i]["amp"] = amps[i]
            self.params[i]["freq"] = freqs[i]
            self.params[i]["on"] = True
            self.amp_scales[i].set(amps[i])
            self.freq_scales[i].set(freqs[i])
            self.toggles[i].set(True)
            self.amp_labels[i].config(text=f"{amps[i]:.2f}")
            self.freq_labels[i].config(text=f"{freqs[i]:g} Гц")
        self.redraw()

    def reset(self):
        defaults = [
            {"amp": 1.0, "freq": 1.0},
            {"amp": 0.5, "freq": 2.0},
            {"amp": 0.3, "freq": 3.0},
            {"amp": 0.2, "freq": 5.0},
            {"amp": 0.15, "freq": 7.0},
        ]
        for i, d in enumerate(defaults):
            self.params[i]["amp"] = d["amp"]
            self.params[i]["freq"] = d["freq"]
            self.params[i]["on"] = True
            self.amp_scales[i].set(d["amp"])
            self.freq_scales[i].set(d["freq"])
            self.toggles[i].set(True)
            self.amp_labels[i].config(text=f"{d['amp']:.2f}")
            self.freq_labels[i].config(text=f"{d['freq']:g} Гц")
        self.redraw()

    # ─── Отрисовка ─────────────────────────────────────────────
    def redraw(self):
        c = self.canvas
        c.delete("all")

        W = 1200
        H = 380

        x0, x1 = 70, W - 30
        y0, y1 = 30, H - 40

        # Окно времени: 0…2 секунды
        t_min, t_max = 0.0, 2.0

        # Считаем максимальную амплитуду суммы для масштаба
        total_max = sum(p["amp"] for p in self.params if p["on"])
        ymax_scale = max(total_max, 1.0) * 1.15

        def to_px(t):
            return x0 + (t - t_min) / (t_max - t_min) * (x1 - x0)

        def to_py(y):
            return y1 - (y + ymax_scale) / (2 * ymax_scale) * (y1 - y0)

        # ═══ Сетка ══════════════════════════════════════════════
        for i in range(9):
            t = t_min + (t_max - t_min) * i / 8
            px = to_px(t)
            c.create_line(px, y0, px, y1, fill=GRID_COLOR)

        # Горизонтальная сетка
        step = ymax_scale / 4
        for i in range(-4, 5):
            py = to_py(i * step)
            c.create_line(x0, py, x1, py, fill=GRID_COLOR)

        # ═══ Оси ════════════════════════════════════════════════
        cy = to_py(0)

        # Ось X
        c.create_line(x0 - 15, cy, x1 + 15, cy,
                      fill=AXIS_COLOR, width=1,
                      arrow="last", arrowshape=(10, 12, 4))
        # Ось Y
        c.create_line(x0, y1 + 10, x0, y0 - 10,
                      fill=AXIS_COLOR, width=1,
                      arrow="last", arrowshape=(10, 12, 4))

        # Подписи осей
        c.create_text(x1 + 20, cy + 14, text="t, с",
                      font=("Segoe UI", 10, "italic"), fill=TEXT)
        c.create_text(x0 - 14, y0 - 20, text="y",
                      font=("Segoe UI", 10, "italic"), fill=TEXT)

        # Деления оси X — каждые 0.25 с
        t = t_min
        while t <= t_max + 0.001:
            px = to_px(t)
            c.create_line(px, cy - 4, px, cy + 4,
                          fill=AXIS_COLOR, width=1)
            c.create_text(px, cy + 16,
                          text=f"{t:.2f}",
                          font=("Segoe UI", 7),
                          fill=MUTED)
            t += 0.25

        # ═══ Рисуем 5 отдельных колебаний ═══════════════════════
        n_points = 800
        for i, p in enumerate(self.params):
            if not p["on"]:
                continue

            points = []
            for k in range(n_points + 1):
                t_val = t_min + (t_max - t_min) * k / n_points
                y_val = p["amp"] * math.sin(2 * math.pi * p["freq"] * t_val)
                points.extend([to_px(t_val), to_py(y_val)])

            c.create_line(*points,
                          fill=COLORS[i], width=2,
                          capstyle="round")

        # ═══ Рисуем сумму ═══════════════════════════════════════
        sum_points = []
        for k in range(n_points + 1):
            t_val = t_min + (t_max - t_min) * k / n_points
            y_sum = 0
            for p in self.params:
                if p["on"]:
                    y_sum += p["amp"] * math.sin(2 * math.pi * p["freq"] * t_val)
            sum_points.extend([to_px(t_val), to_py(y_sum)])

        c.create_line(*sum_points,
                      fill=SUM_COLOR, width=3,
                      capstyle="round")

        # ═══ Подписи значений ═══════════════════════════════════
        active = [p for p in self.params if p["on"]]
        if active:
            info = "  ·  ".join(
                f"A{i+1}={p['amp']:.2f}, f{i+1}={p['freq']:.1f}"
                for i, p in enumerate(self.params) if p["on"]
            )
            c.create_text(x0 + 8, y0 + 6,
                          text=info,
                          font=("Consolas", 9),
                          fill=MUTED, anchor="nw")

        # ═══ Заголовок графика ══════════════════════════════════
        c.create_text((x0 + x1) / 2, y0 - 12,
                      text=f"Сумма {len(active)} колебаний",
                      font=("Segoe UI", 11, "bold"),
                      fill=SUM_COLOR)


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = HarmonicsApp(root)
    root.mainloop()
