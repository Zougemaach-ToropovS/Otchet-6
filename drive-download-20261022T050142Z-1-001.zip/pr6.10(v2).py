import tkinter as tk
import math
import random


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

SIGNAL = "#1e5fff"
ENVELOPE = "#e53935"
AXIS = "#000000"
GRID = "#ececf0"
ZERO = "#c0c0c0"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class ModulationApp:
    def __init__(self, root):
        self.root = root
        root.title("Цифровые модуляции: ASK, FSK, PSK")
        root.geometry("880x720")
        root.minsize(820, 680)
        root.configure(bg=BG)
        root.resizable(False, False)

        self.bits = [1, 0, 1, 1, 0, 0, 1, 0]
        self.fc = 15.0
        self.fs = 2.0
        self.ask_depth = 100
        self.fsk_deviation = 50

        self._build_header()
        self._build_input()
        self._build_plots()
        self._build_controls()

        self.redraw()

    # ════════════════════════════════════════════════════════════
    # ЗАГОЛОВОК
    # ════════════════════════════════════════════════════════════
    def _build_header(self):
        tk.Label(self.root, text="Цифровые виды модуляции",
                 font=("Segoe UI", 14, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(10, 2))

        tk.Label(self.root,
                 text="ASK · FSK · PSK",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 6))

    # ════════════════════════════════════════════════════════════
    # ВВОД
    # ════════════════════════════════════════════════════════════
    def _build_input(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=16, pady=(0, 8), fill="x")

        row = tk.Frame(card, bg=CARD)
        row.pack(padx=12, pady=8, fill="x")

        tk.Label(row, text="Биты:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 8))

        self.entry = tk.Entry(row, font=("Consolas", 12, "bold"),
                              bg="#fafafa", fg=TEXT,
                              bd=1, relief="solid",
                              highlightthickness=1,
                              highlightbackground=BORDER,
                              highlightcolor=ACCENT,
                              width=30)
        self.entry.pack(side="left", padx=(0, 8), ipady=4)
        self.entry.insert(0, "10110010")

        self._btn(row, "🎲", ACCENT, ACCENT_HOVER,
                  self.random_bits, width=3).pack(side="left", padx=2)
        self._btn(row, "✓", GREEN, GREEN_HOVER,
                  self.apply, width=3).pack(side="left", padx=2)
        self._btn(row, "1010", ORANGE, ORANGE_HOVER,
                  self.set_alternating).pack(side="left", padx=2)

    def random_bits(self):
        n = random.choice([8, 10, 12, 16])
        s = "".join(random.choice("01") for _ in range(n))
        self.entry.delete(0, tk.END)
        self.entry.insert(0, s)
        self.apply()

    def set_alternating(self):
        self.entry.delete(0, tk.END)
        self.entry.insert(0, "10101010")
        self.apply()

    def apply(self):
        s = "".join(c for c in self.entry.get() if c in "01")
        if not s:
            s = "10101010"
            self.entry.delete(0, tk.END)
            self.entry.insert(0, s)
        self.bits = [int(c) for c in s]
        self.redraw()

    # ════════════════════════════════════════════════════════════
    # ГРАФИКИ
    # ════════════════════════════════════════════════════════════
    def _build_plots(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=16, pady=(0, 8))

        self.canvas = tk.Canvas(card, width=840, height=480,
                                bg="white", highlightthickness=0)
        self.canvas.pack(padx=10, pady=10)

    # ════════════════════════════════════════════════════════════
    # ПАРАМЕТРЫ
    # ════════════════════════════════════════════════════════════
    def _build_controls(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=16, pady=(0, 12), fill="x")

        row1 = tk.Frame(card, bg=CARD)
        row1.pack(fill="x", padx=12, pady=(8, 4))

        self._slider(row1, "f_c", "Гц",
                     5, 30, self.fc, 1,
                     self._set_fc, SIGNAL)

        self._slider(row1, "f_s", "Гц",
                     1, 10, self.fs, 0.5,
                     self._set_fs, ENVELOPE)

        row2 = tk.Frame(card, bg=CARD)
        row2.pack(fill="x", padx=12, pady=(0, 8))

        self._slider(row2, "ASK", "%",
                     0, 100, self.ask_depth, 5,
                     self._set_ask, PURPLE)

        self._slider(row2, "FSK", "%",
                     10, 100, self.fsk_deviation, 5,
                     self._set_fsk, ORANGE)

    def _slider(self, parent, label, unit, vmin, vmax, initial, step,
                callback, color):
        f = tk.Frame(parent, bg=CARD)
        f.pack(side="left", fill="x", expand=True, padx=(0, 12))

        header = tk.Frame(f, bg=CARD)
        header.pack(fill="x")

        tk.Label(header, text=label,
                 font=("Segoe UI", 8, "bold"),
                 bg=CARD, fg=MUTED).pack(side="left")

        lbl = tk.Label(header, text=f"{initial:g} {unit}".strip(),
                       font=("Consolas", 9, "bold"),
                       bg=CARD, fg=color)
        lbl.pack(side="right")

        def on_move(v):
            val = float(v)
            callback(val)
            if unit == "%":
                lbl.config(text=f"{int(val)} %")
            elif unit == "Гц":
                lbl.config(text=f"{val:.1f} Гц")
            else:
                lbl.config(text=f"{val:g} {unit}")
            self.redraw()

        scale = tk.Scale(f, from_=vmin, to=vmax, resolution=step,
                         orient="horizontal", showvalue=False,
                         bg=CARD, fg=TEXT, troughcolor="#ececf0",
                         activebackground=color,
                         highlightthickness=0, bd=0,
                         sliderlength=14, width=6,
                         command=on_move)
        scale.set(initial)
        scale.pack(fill="x", pady=(2, 0))
        return scale

    def _set_fc(self, v): self.fc = v
    def _set_fs(self, v): self.fs = v
    def _set_ask(self, v): self.ask_depth = v
    def _set_fsk(self, v): self.fsk_deviation = v

    def _btn(self, parent, text, bg, hover, command, width=None):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 9, "bold"),
                        bg=bg, fg="#ffffff",
                        activebackground=hover,
                        activeforeground="#ffffff",
                        bd=0, padx=10, pady=6, cursor="hand2",
                        command=command)
        if width:
            btn.config(width=width)
        return btn

    # ════════════════════════════════════════════════════════════
    # ОТРИСОВКА
    # ════════════════════════════════════════════════════════════
    def redraw(self):
        c = self.canvas
        c.delete("all")

        W = 840
        H = 480
        section_h = H // 3

        self._draw_section(c, 0 * section_h, section_h,
                           "ASK", "1 — сигнал, 0 — нет", self._ask_signal)
        self._draw_section(c, 1 * section_h, section_h,
                           "FSK", "1 — выс. частота, 0 — низ.", self._fsk_signal)
        self._draw_section(c, 2 * section_h, section_h,
                           "PSK", "1 — фаза 0°, 0 — фаза 180°", self._psk_signal)

    def _draw_section(self, c, y_base, section_h, title, subtitle, func):
        W = 840
        x0, x1 = 50, W - 30
        y_top = y_base + 30
        y_bot = y_base + section_h - 25
        cy = (y_top + y_bot) / 2

        c.create_text(x0, y_base + 12,
                      text=title,
                      font=("Segoe UI", 10, "bold"),
                      fill=TEXT, anchor="w")
        c.create_text(x0 + 50, y_base + 12,
                      text=subtitle,
                      font=("Segoe UI", 8),
                      fill=MUTED, anchor="w")

        n = len(self.bits)
        t_max = n / self.fs

        # Сетка
        for i in range(n + 1):
            t = i / self.fs
            px = x0 + (t / t_max) * (x1 - x0)
            c.create_line(px, y_top, px, y_bot, fill=GRID, width=1)

        # Ноль
        c.create_line(x0, cy, x1, cy, fill=ZERO, width=1)
        c.create_line(x0 - 10, cy, x1 + 8, cy, fill=AXIS, width=1,
                      arrow="last", arrowshape=(6, 8, 2))

        # Подписи бит
        for i, bit in enumerate(self.bits):
            t_center = (i + 0.5) / self.fs
            px = x0 + (t_center / t_max) * (x1 - x0)
            c.create_text(px, y_bot + 8,
                          text=str(bit),
                          font=("Consolas", 9, "bold"),
                          fill=ACCENT if bit == 1 else MUTED)

        # Сигнал
        points = func(x0, x1, cy, y_top, y_bot, t_max)
        c.create_line(*points, fill=SIGNAL, width=1.5)

    def _ask_signal(self, x0, x1, cy, y_top, y_bot, t_max):
        n = len(self.bits)
        amplitude = (y_bot - y_top) / 2 * 0.85
        depth = self.ask_depth / 100.0

        points = []
        samples = 60
        total = n * samples

        for i in range(total + 1):
            t = t_max * i / total
            bit_idx = min(n - 1, int(t * self.fs))
            bit = self.bits[bit_idx]
            amp = amplitude if bit == 1 else amplitude * (1 - depth)
            y = amp * math.sin(2 * math.pi * self.fc * t)
            px = x0 + (t / t_max) * (x1 - x0)
            points.extend([px, cy - y])
        return points

    def _fsk_signal(self, x0, x1, cy, y_top, y_bot, t_max):
        n = len(self.bits)
        amplitude = (y_bot - y_top) / 2 * 0.85
        dev = self.fsk_deviation / 100.0
        f_high = self.fc * (1 + dev)
        f_low = self.fc * (1 - dev)

        points = []
        samples = 80
        total = n * samples
        phase = 0.0

        for i in range(total + 1):
            t = t_max * i / total
            bit_idx = min(n - 1, int(t * self.fs))
            bit = self.bits[bit_idx]
            f = f_high if bit == 1 else f_low
            dt = t_max / total
            phase += 2 * math.pi * f * dt
            y = amplitude * math.sin(phase)
            px = x0 + (t / t_max) * (x1 - x0)
            points.extend([px, cy - y])
        return points

    def _psk_signal(self, x0, x1, cy, y_top, y_bot, t_max):
        n = len(self.bits)
        amplitude = (y_bot - y_top) / 2 * 0.85

        points = []
        samples = 80
        total = n * samples

        for i in range(total + 1):
            t = t_max * i / total
            bit_idx = min(n - 1, int(t * self.fs))
            bit = self.bits[bit_idx]
            phase = 0 if bit == 1 else math.pi
            y = amplitude * math.sin(2 * math.pi * self.fc * t + phase)
            px = x0 + (t / t_max) * (x1 - x0)
            points.extend([px, cy - y])
        return points


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = ModulationApp(root)
    root.mainloop()
