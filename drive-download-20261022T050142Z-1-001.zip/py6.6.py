import tkinter as tk
import math


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#ffffff"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

AXIS_COLOR = "#000000"
GRID_COLOR = "#e8e8ee"
TICK_COLOR = "#333333"
SIN_COLOR = "#e53935"       # красный
COS_COLOR = "#0a84ff"       # синий
LABEL_BG = "#ffffff"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
ACCENT_PRESS = "#004c99"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class SinCosApp:
    def __init__(self, root):
        self.root = root
        root.title("Графики sin(x) и cos(x)")
        root.geometry("1060x720")
        root.minsize(960, 680)
        root.configure(bg=BG)
        root.resizable(False, False)

        self.animating = False
        self.anim_phase = 0.0

        # ═══ Заголовок ═══════════════════════════════════════════
        tk.Label(root, text="Графики sin(x) и cos(x)",
                 font=("Segoe UI", 16, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(14, 3))

        tk.Label(root,
                 text="Красная — sin(x) · Синяя — cos(x)",
                 font=("Segoe UI", 10),
                 bg=BG, fg=MUTED).pack(pady=(0, 10))

        # ═══ Карточка с Canvas ═══════════════════════════════════
        card = tk.Frame(root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=20, pady=(0, 12))

        # Canvas — область рисования
        self.canvas = tk.Canvas(card, width=1000, height=460,
                                bg="white", highlightthickness=0)
        self.canvas.pack(padx=15, pady=15)

        # ═══ Управление ══════════════════════════════════════════
        ctrl = tk.Frame(root, bg=BG)
        ctrl.pack(pady=(0, 16))

        # Ползунок амплитуды
        amp_frame = tk.Frame(ctrl, bg=BG)
        amp_frame.pack(side="left", padx=(0, 20))

        tk.Label(amp_frame, text="Амплитуда",
                 font=("Segoe UI", 9, "bold"),
                 bg=BG, fg=MUTED).pack()

        self.amp_label = tk.Label(amp_frame, text="1.00",
                                  font=("Consolas", 11, "bold"),
                                  bg=BG, fg=TEXT)
        self.amp_label.pack()

        self.amp_scale = tk.Scale(
            amp_frame, from_=0.1, to=2.0, resolution=0.05,
            orient="horizontal", length=200,
            showvalue=False,
            bg=BG, fg=TEXT, troughcolor="#d8d8d8",
            activebackground=SIN_COLOR,
            highlightthickness=0, bd=0,
            sliderlength=18, width=8,
            command=self.on_amp_change,
        )
        self.amp_scale.set(1.0)
        self.amp_scale.pack()

        # Кнопка «Анимация»
        self.btn_anim = tk.Button(
            ctrl, text="▶  Анимация",
            font=("Segoe UI", 11, "bold"),
            bg=GREEN, fg="#ffffff",
            activebackground=GREEN_HOVER, activeforeground="#ffffff",
            bd=0, padx=22, pady=12, cursor="hand2",
            command=self.toggle_anim,
        )
        self.btn_anim.pack(side="left", padx=4)

        # Кнопка «Сброс»
        self.btn_reset = tk.Button(
            ctrl, text="↻  Сброс",
            font=("Segoe UI", 11, "bold"),
            bg=ACCENT, fg="#ffffff",
            activebackground=ACCENT_HOVER, activeforeground="#ffffff",
            bd=0, padx=22, pady=12, cursor="hand2",
            command=self.reset,
        )
        self.btn_reset.pack(side="left", padx=4)

        # Первичная отрисовка
        self.redraw()

    # ─── Обработчики ───────────────────────────────────────────
    def on_amp_change(self, value):
        self.amp_label.config(text=f"{float(value):.2f}")
        self.redraw()

    def toggle_anim(self):
        self.animating = not self.animating
        if self.animating:
            self.btn_anim.config(text="⏹  Стоп",
                                 bg=SIN_COLOR,
                                 activebackground="#c62828")
            self._anim_tick()
        else:
            self.btn_anim.config(text="▶  Анимация",
                                 bg=GREEN,
                                 activebackground=GREEN_HOVER)

    def reset(self):
        self.animating = False
        self.anim_phase = 0.0
        self.btn_anim.config(text="▶  Анимация",
                             bg=GREEN,
                             activebackground=GREEN_HOVER)
        self.amp_scale.set(1.0)
        self.redraw()

    def _anim_tick(self):
        if not self.animating:
            return
        self.anim_phase += 0.06
        self.redraw()
        self.root.after(30, self._anim_tick)

    # ─── Отрисовка ─────────────────────────────────────────────
    def redraw(self):
        c = self.canvas
        c.delete("all")

        # ═══ Геометрия ══════════════════════════════════════════
        W = 1000
        H = 460

        # Отступы: слева — под подписи Y, снизу — под подписи X
        margin_left = 80
        margin_right = 50
        margin_top = 40
        margin_bottom = 70

        # Область графика
        x0 = margin_left
        x1 = W - margin_right
        y0 = margin_top
        y1 = H - margin_bottom

        # Центр по вертикали (ось X)
        cy = (y0 + y1) / 2

        # Ось X: 0 … 2π
        xmin, xmax = 0, 2 * math.pi
        # Ось Y: -1.3 … 1.3 (с запасом для подписей)
        ymin, ymax = -1.3, 1.3

        # Функции преобразования
        def to_px(x_val):
            """Значение X → пиксель."""
            return x0 + (x_val - xmin) / (xmax - xmin) * (x1 - x0)

        def to_py(y_val):
            """Значение Y → пиксель."""
            return y1 - (y_val - ymin) / (ymax - ymin) * (y1 - y0)

        amp = self.amp_scale.get()
        phase = self.anim_phase

        # ═══ Сетка ══════════════════════════════════════════════
        # Вертикальные линии через π/4
        for i in range(9):
            x_val = i * math.pi / 4
            px = to_px(x_val)
            c.create_line(px, y0, px, y1,
                          fill=GRID_COLOR, width=1)
        # Горизонтальные линии через 0.5
        for i in range(-3, 4):
            y_val = i * 0.5
            py = to_py(y_val)
            c.create_line(x0, py, x1, py,
                          fill=GRID_COLOR, width=1)

        # ═══ Оси ════════════════════════════════════════════════
        # Ось X (горизонтальная)
        c.create_line(x0 - 20, cy, x1 + 20, cy,
                      fill=AXIS_COLOR, width=2,
                      arrow="last", arrowshape=(12, 14, 5))
        # Ось Y (вертикальная)
        c.create_line(x0, y1 + 20, x0, y0 - 20,
                      fill=AXIS_COLOR, width=2,
                      arrow="last", arrowshape=(12, 14, 5))

        # Подписи осей
        c.create_text(x1 + 30, cy + 15, text="x",
                      font=("Segoe UI", 12, "italic"), fill=AXIS_COLOR)
        c.create_text(x0 - 12, y0 - 30, text="y",
                      font=("Segoe UI", 12, "italic"), fill=AXIS_COLOR)

        # ═══ Деления по оси X — через π/4 ═══════════════════════
        # Подписи: 0, π/4, π/2, 3π/4, π, 5π/4, 3π/2, 7π/4, 2π
        pi_labels = [
            "0",
            "π/4",
            "π/2",
            "3π/4",
            "π",
            "5π/4",
            "3π/2",
            "7π/4",
            "2π",
        ]
        for i in range(9):
            x_val = i * math.pi / 4
            px = to_px(x_val)
            # Риска на оси X
            c.create_line(px, cy - 5, px, cy + 5,
                          fill=AXIS_COLOR, width=2)
            # Подпись
            c.create_text(px, cy + 22,
                          text=pi_labels[i],
                          font=("Segoe UI", 9),
                          fill=TEXT)

        # ═══ Деления по оси Y ══════════════════════════════════
        y_labels = [(-1.0, "−1"), (-0.5, "−0.5"),
                    (0.5, "0.5"), (1.0, "1")]
        for y_val, label in y_labels:
            py = to_py(y_val)
            c.create_line(x0 - 5, py, x0 + 5, py,
                          fill=AXIS_COLOR, width=2)
            c.create_text(x0 - 22, py,
                          text=label,
                          font=("Segoe UI", 9),
                          fill=TEXT, anchor="e")

        # Подпись 0 (пересечение осей)
        c.create_text(x0 - 12, cy + 12, text="0",
                      font=("Segoe UI", 9), fill=TEXT)

        # ═══ Функция sin(x) — красная ═══════════════════════════
        sin_points = []
        n_steps = 400
        for i in range(n_steps + 1):
            x_val = xmin + (xmax - xmin) * i / n_steps
            y_val = amp * math.sin(x_val + phase)
            sin_points.extend([to_px(x_val), to_py(y_val)])

        c.create_line(*sin_points,
                      fill=SIN_COLOR, width=3,
                      smooth=True, capstyle="round")

        # ═══ Функция cos(x) — синяя пунктирная ══════════════════
        cos_points = []
        for i in range(n_steps + 1):
            x_val = xmin + (xmax - xmin) * i / n_steps
            y_val = amp * math.cos(x_val + phase)
            cos_points.extend([to_px(x_val), to_py(y_val)])

        c.create_line(*cos_points,
                      fill=COS_COLOR, width=3,
                      dash=(8, 5),
                      smooth=True, capstyle="round")

        # ═══ Подписи функций ════════════════════════════════════
        # sin(x) — возле первого максимума
        sin_label_x = to_px(math.pi / 2)
        sin_label_y = to_py(amp * 1.0) - 20
        c.create_text(sin_label_x, sin_label_y,
                      text="sin(x)",
                      font=("Segoe UI", 11, "italic"),
                      fill=SIN_COLOR)

        # cos(x) — возле первого минимума
        cos_label_x = to_px(math.pi)
        cos_label_y = to_py(-amp * 1.0) + 20
        c.create_text(cos_label_x, cos_label_y,
                      text="cos(x)",
                      font=("Segoe UI", 11, "italic"),
                      fill=COS_COLOR)


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = SinCosApp(root)
    root.mainloop()
