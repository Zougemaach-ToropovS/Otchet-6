import tkinter as tk
import base64


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
GREEN = "#30d158"
GREEN_HOVER = "#20a544"
ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
PURPLE = "#8e44ad"
PURPLE_HOVER = "#7d3c98"
RED = "#e53935"
RED_HOVER = "#c62828"


# ─── Кодировки ───────────────────────────────────────────────────
ENCODINGS = [
    ("UTF-8",       "utf-8"),
    ("Windows-1251","cp1251"),
    ("KOI8-R",      "koi8-r"),
    ("ISO-8859-1",  "iso-8859-1"),
    ("ASCII",       "ascii"),
]


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class CodeCalcApp:
    def __init__(self, root):
        self.root = root
        root.title("Калькулятор кодов")
        root.geometry("1000x860")
        root.minsize(920, 820)
        root.configure(bg=BG)
        root.resizable(False, False)

        self.encoding_var = tk.StringVar(value="UTF-8")
        self.last_bytes = b""

        self._build_header()
        self._build_input()
        self._build_results()
        self._build_reverse()

        self.convert()

    # ════════════════════════════════════════════════════════════
    # ЗАГОЛОВОК
    # ════════════════════════════════════════════════════════════
    def _build_header(self):
        tk.Label(self.root, text="Калькулятор кодов",
                 font=("Segoe UI", 16, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(12, 2))

        tk.Label(self.root,
                 text="Текст ↔ UTF-8 · CP1251 · KOI8-R · ISO-8859-1 · ASCII · Base64",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

    # ════════════════════════════════════════════════════════════
    # ВВОД
    # ════════════════════════════════════════════════════════════
    def _build_input(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=20, pady=(0, 8), fill="x")

        # Кодировка
        row1 = tk.Frame(card, bg=CARD)
        row1.pack(fill="x", padx=16, pady=(12, 6))

        tk.Label(row1, text="Кодировка:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 8))

        for name, _ in ENCODINGS:
            tk.Radiobutton(row1, text=name,
                           variable=self.encoding_var, value=name,
                           font=("Segoe UI", 9),
                           bg=CARD, fg=TEXT,
                           activebackground=CARD,
                           activeforeground=ACCENT,
                           selectcolor=CARD,
                           bd=0, highlightthickness=0,
                           cursor="hand2",
                           command=self.convert,
                           ).pack(side="left", padx=(0, 10))

        # Текст
        row2 = tk.Frame(card, bg=CARD)
        row2.pack(fill="x", padx=16, pady=(0, 12))

        tk.Label(row2, text="Текст:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(anchor="w", pady=(0, 4))

        self.text_input = tk.Text(row2, height=3,
                                  font=("Consolas", 11),
                                  bg="#fafafa", fg=TEXT,
                                  bd=1, relief="solid",
                                  highlightthickness=1,
                                  highlightbackground=BORDER,
                                  highlightcolor=ACCENT,
                                  wrap="word",
                                  padx=8, pady=6)
        self.text_input.pack(fill="x")
        self.text_input.insert("1.0", "Привет, мир!")

        # Кнопки
        btns = tk.Frame(card, bg=CARD)
        btns.pack(fill="x", padx=16, pady=(0, 12))

        self._btn(btns, "🔄 Перевести →", ACCENT, ACCENT_HOVER,
                  self.convert).pack(side="left", padx=(0, 6))

        self._btn(btns, "🧹 Очистить", ORANGE, ORANGE_HOVER,
                  self.clear_all).pack(side="left", padx=6)

        self._btn(btns, "📋 Копировать всё", GREEN, GREEN_HOVER,
                  self.copy_all).pack(side="left", padx=6)

        self._btn(btns, "📥 Экспорт", PURPLE, PURPLE_HOVER,
                  self.export).pack(side="left", padx=6)

    # ════════════════════════════════════════════════════════════
    # РЕЗУЛЬТАТЫ
    # ════════════════════════════════════════════════════════════
    def _build_results(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=20, pady=(0, 8), fill="both", expand=True)

        tk.Label(card, text="РЕЗУЛЬТАТ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=16, pady=(10, 4))

        # Прокручиваемая область с результатами
        wrap = tk.Frame(card, bg=CARD)
        wrap.pack(fill="both", expand=True, padx=16, pady=(0, 12))

        self.results_text = tk.Text(wrap, height=14,
                                    font=("Consolas", 10),
                                    bg="#fafafa", fg=TEXT,
                                    bd=0, relief="flat",
                                    highlightthickness=0,
                                    wrap="word",
                                    padx=10, pady=8,
                                    state="disabled")
        self.results_text.pack(side="left", fill="both", expand=True)

        sb = tk.Scrollbar(wrap, command=self.results_text.yview,
                          bd=0, relief="flat", width=10)
        sb.pack(side="right", fill="y")
        self.results_text.config(yscrollcommand=sb.set)

        # Теги для цветов
        self.results_text.tag_configure("label", foreground=ACCENT,
                                        font=("Consolas", 10, "bold"))
        self.results_text.tag_configure("value", foreground=TEXT)
        self.results_text.tag_configure("hex", foreground=PURPLE)
        self.results_text.tag_configure("bin", foreground=ORANGE)
        self.results_text.tag_configure("dec", foreground=GREEN)
        self.results_text.tag_configure("b64", foreground=RED)

    # ════════════════════════════════════════════════════════════
    # ОБРАТНЫЙ ПЕРЕВОД
    # ════════════════════════════════════════════════════════════
    def _build_reverse(self):
        card = tk.Frame(self.root, bg=CARD,
                        highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(padx=20, pady=(0, 16), fill="x")

        tk.Label(card, text="ОБРАТНЫЙ ПЕРЕВОД: DEC / HEX / BIN / Base64 → ТЕКСТ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED, anchor="w"
                 ).pack(fill="x", padx=16, pady=(10, 4))

        row = tk.Frame(card, bg=CARD)
        row.pack(fill="x", padx=16, pady=(0, 8))

        self.reverse_input = tk.Entry(row,
                                      font=("Consolas", 11),
                                      bg="#fafafa", fg=TEXT,
                                      bd=1, relief="solid",
                                      highlightthickness=1,
                                      highlightbackground=BORDER,
                                      highlightcolor=ACCENT)
        self.reverse_input.pack(side="left", fill="x", expand=True,
                                ipady=6, padx=(0, 8))

        self.reverse_input.insert(0, "0xEF 0xBB 0xBF")

        self._btn(row, "← Перевести", PURPLE, PURPLE_HOVER,
                  self.reverse_convert).pack(side="left")

        # Результат
        self.reverse_result = tk.Label(card, text="",
                                       font=("Consolas", 12, "bold"),
                                       bg=CARD, fg=GREEN,
                                       anchor="w", wraplength=900,
                                       justify="left")
        self.reverse_result.pack(fill="x", padx=16, pady=(0, 12))

    # ════════════════════════════════════════════════════════════
    # ПЕРЕВОД
    # ════════════════════════════════════════════════════════════
    def convert(self):
        text = self.text_input.get("1.0", "end-1c")
        if not text:
            self._set_results("")
            return

        encoding_name = self.encoding_var.get()
        encoding_code = dict(ENCODINGS)[encoding_name]

        self.results_text.config(state="normal")
        self.results_text.delete("1.0", "end")

        # Заголовок
        self.results_text.insert("end",
                                 f"Текст: {text}\n", "label")
        self.results_text.insert("end",
                                 f"Кодировка: {encoding_name}\n\n", "label")

        # Кодируем в байты
        try:
            data = text.encode(encoding_code)
            self.last_bytes = data
        except UnicodeEncodeError as e:
            self.results_text.insert("end",
                                     f"⚠ Не все символы представимы в "
                                     f"{encoding_name}\n"
                                     f"   {e}\n\n", "label")
            data = text.encode("utf-8", errors="replace")
            self.last_bytes = data

        # DEC, HEX, BIN
        self._write_row("DEC:", " ".join(str(b) for b in data),
                        "dec", data)
        self._write_row("HEX:", " ".join(f"0x{b:02X}" for b in data),
                        "hex", data)
        self._write_row("BIN:", " ".join(f"{b:08b}" for b in data),
                        "bin", data)

        # Base64
        b64 = base64.b64encode(data).decode("ascii")
        self._write_row("Base64:", b64, "b64", data)

        # Символы и коды
        self.results_text.insert("end", "\n", "value")
        self.results_text.insert("end",
                                 "Символ  →  DEC  HEX   BIN\n", "label")
        for ch in text:
            try:
                code = ord(ch)
                b = ch.encode(encoding_code, errors="replace")
                dec = b[0] if len(b) == 1 else "—"
                hexv = f"0x{b[0]:02X}" if len(b) == 1 else "—"
                binv = f"{b[0]:08b}" if len(b) == 1 else "—"
                self.results_text.insert(
                    "end",
                    f"  {ch!r:>6}  →  {dec:>4}  {hexv:>6}  {binv:>10}\n",
                    "value")
            except Exception:
                pass

        self.results_text.config(state="disabled")

    def _write_row(self, label, value, tag, data):
        self.results_text.insert("end", f"{label}\n", "label")
        self.results_text.insert("end", f"  {value}\n\n", tag)

    def _set_results(self, text):
        self.results_text.config(state="normal")
        self.results_text.delete("1.0", "end")
        self.results_text.insert("end", text)
        self.results_text.config(state="disabled")

    # ════════════════════════════════════════════════════════════
    # ОБРАТНЫЙ ПЕРЕВОД
    # ════════════════════════════════════════════════════════════
    def reverse_convert(self):
        text = self.reverse_input.get().strip()
        if not text:
            self.reverse_result.config(text="", fg=MUTED)
            return

        encoding_name = self.encoding_var.get()
        encoding_code = dict(ENCODINGS)[encoding_name]

        try:
            # Определяем формат по префиксам
            if text.startswith("0x") or " 0x" in text:
                # HEX
                parts = text.replace("0x", "").replace(",", " ").split()
                data = bytes(int(p, 16) for p in parts)
            elif all(c in "01 " for c in text):
                # BIN
                parts = text.split()
                data = bytes(int(p, 2) for p in parts)
            elif all(c.isdigit() or c == " " for c in text):
                # DEC
                parts = text.split()
                data = bytes(int(p) for p in parts)
            else:
                # Base64
                data = base64.b64decode(text)

            # Декодируем
            result = data.decode(encoding_code, errors="replace")
            self.reverse_result.config(
                text=f"Результат: {result}",
                fg=GREEN)

        except Exception as e:
            self.reverse_result.config(
                text=f"⚠ Ошибка: {e}",
                fg=RED)

    # ════════════════════════════════════════════════════════════
    # КНОПКИ
    # ════════════════════════════════════════════════════════════
    def clear_all(self):
        self.text_input.delete("1.0", "end")
        self.reverse_input.delete(0, "end")
        self.reverse_result.config(text="", fg=MUTED)
        self._set_results("")

    def copy_all(self):
        self.root.clipboard_clear()
        self.root.clipboard_append(self.results_text.get("1.0", "end-1c"))

    def export(self):
        from datetime import datetime
        path = f"codes_{datetime.now().strftime('%Y%m%d_%H%M')}.txt"
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.results_text.get("1.0", "end-1c"))
            self.reverse_result.config(text=f"Сохранено: {path}", fg=GREEN)
        except Exception as e:
            self.reverse_result.config(text=f"Ошибка: {e}", fg=RED)

    def _btn(self, parent, text, bg, hover, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="#ffffff",
                        activebackground=hover,
                        activeforeground="#ffffff",
                        bd=0, padx=14, pady=8, cursor="hand2",
                        command=command)

        def on_enter(e):
            btn.config(bg=hover)

        def on_leave(e):
            btn.config(bg=bg)

        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        return btn


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = CodeCalcApp(root)
    root.mainloop()
