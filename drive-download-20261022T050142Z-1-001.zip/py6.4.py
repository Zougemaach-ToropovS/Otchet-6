import tkinter as tk
import random


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

ACCENT = "#0a84ff"
ACCENT_HOVER = "#0066cc"
ACCENT_PRESS = "#004c99"

GREEN = "#30d158"
GREEN_HOVER = "#20a544"
GREEN_PRESS = "#187a33"

ORANGE = "#ff9f0a"
ORANGE_HOVER = "#cc7f08"
ORANGE_PRESS = "#a36606"

WAVE_GREEN = "#00ff00"
WAVE_CYAN = "#00ffff"
WAVE_YELLOW = "#ffff00"
WAVE_MAGENTA = "#ff00ff"
WAVE_ORANGE = "#ff8800"

PLOT_BG = "#0a0a0a"
PLOT_GRID = "#1a3a1a"


# ═══════════════════════════════════════════════════════════════════
# КОДИРОВАНИЕ
# ═══════════════════════════════════════════════════════════════════
def encode_nrz(bits):
    return [(1 if b == 1 else 0, 1) for b in bits]


def encode_manchester(bits):
    points = []
    for b in bits:
        if b == 1:
            points.append((0, 0.5))
            points.append((1, 0.5))
        else:
            points.append((1, 0.5))
            points.append((0, 0.5))
    return points


def encode_mlt3(bits):
    levels = [-1, 0, 1]
    idx = 1
    points = []
    for b in bits:
        if b == 1:
            idx = (idx + 1) % 3
        points.append((levels[idx], 1))
    return points


def encode_ami(bits):
    points = []
    last = -1
    for b in bits:
        if b == 0:
            points.append((0, 1))
        else:
            last = -last
            points.append((last, 1))
    return points


def encode_pulse(bits):
    points = []
    for b in bits:
        level = 1 if b == 1 else 0
        points.append((level, 0.5))
        points.append((0, 0.5))
    return points


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class EncodingApp:
    def __init__(self, root):
        self.root = root
        root.title("Кодирование битовой последовательности")
        root.geometry("1060x860")
        root.minsize(960, 820)
        root.configure(bg=BG)
        root.resizable(False, False)

        self.bits = []

        # Заголовок
        tk.Label(root, text="Кодирование битовой последовательности",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(10, 2))

        tk.Label(root,
                 text="NRZ · Манчестер · MLT-3 · AMI · Импульсное",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 8))

        # Панель ввода
        input_frame = tk.Frame(root, bg=CARD,
                               highlightthickness=1,
                               highlightbackground=BORDER)
        input_frame.pack(padx=24, pady=(0, 8), fill="x")

        row = tk.Frame(input_frame, bg=CARD)
        row.pack(padx=18, pady=(10, 4), fill="x")

        tk.Label(row, text="Битовая последовательность:",
                 font=("Segoe UI", 10, "bold"),
                 bg=CARD, fg=TEXT).pack(side="left", padx=(0, 10))

        self.entry = tk.Entry(row,
                              font=("Consolas", 13, "bold"),
                              bg="#fafafa", fg=TEXT,
                              bd=1, relief="solid",
                              highlightthickness=1,
                              highlightbackground=BORDER,
                              highlightcolor=ACCENT,
                              width=55)
        self.entry.pack(side="left", padx=(0, 10), ipady=5)
        self.entry.insert(0, "01001011110110100")

        btns = tk.Frame(input_frame, bg=CARD)
        btns.pack(padx=18, pady=(0, 10))

        self._make_button(btns, "🎲  Сгенерировать",
                          ACCENT, ACCENT_HOVER, ACCENT_PRESS,
                          self.generate_random).pack(side="left", padx=3)
        self._make_button(btns, "✓  Применить",
                          GREEN, GREEN_HOVER, GREEN_PRESS,
                          self.apply).pack(side="left", padx=3)
        self._make_button(btns, "🧹  Очистить",
                          ORANGE, ORANGE_HOVER, ORANGE_PRESS,
                          self.clear).pack(side="left", padx=3)

        # Панель графиков
        plot_panel = tk.Frame(root, bg=CARD,
                              highlightthickness=1,
                              highlightbackground=BORDER)
        plot_panel.pack(padx=24, pady=(0, 10), fill="both", expand=True)

        # Canvas уменьшен, чтобы всё поместилось
        self.canvas = tk.Canvas(plot_panel, width=1000, height=690,
                                bg=CARD, highlightthickness=0)
        self.canvas.pack(padx=12, pady=12)

        root.bind("<Return>", lambda e: self.apply())
        root.bind("<space>", lambda e: self.generate_random())

        self.apply()

    # ─── Кнопки ────────────────────────────────────────────────
    def _make_button(self, parent, text, bg, hover, press, command):
        btn = tk.Button(parent, text=text,
                        font=("Segoe UI", 10, "bold"),
                        bg=bg, fg="#ffffff",
                        activebackground=press, activeforeground="#ffffff",
                        bd=0, relief="flat",
                        padx=16, pady=9, cursor="hand2",
                        command=command)
        btn.bind("<Enter>", lambda e: btn.config(bg=hover))
        btn.bind("<Leave>", lambda e: btn.config(bg=bg))
        btn.bind("<ButtonPress-1>", lambda e: btn.config(bg=press))
        btn.bind("<ButtonRelease-1>", lambda e: btn.config(bg=hover))
        return btn

    # ─── Действия ──────────────────────────────────────────────
    def generate_random(self):
        n = random.choice([8, 10, 12, 16, 18, 20])
        bits_str = "".join(random.choice("01") for _ in range(n))
        self.entry.delete(0, tk.END)
        self.entry.insert(0, bits_str)
        self.apply()

    def apply(self):
        text = self.entry.get().strip()
        text = "".join(c for c in text if c in "01")
        if not text:
            text = "01001011110110100"
            self.entry.delete(0, tk.END)
            self.entry.insert(0, text)
        self.bits = [int(c) for c in text]
        self.redraw()

    def clear(self):
        self.entry.delete(0, tk.END)
        self.bits = []
        self.canvas.delete("all")

    # ─── Отрисовка ─────────────────────────────────────────────
    def redraw(self):
        self.canvas.delete("all")
        if not self.bits:
            return

        # Геометрия — уменьшены высоты и отступы
        W = 970
        x0 = 15
        y_start = 18
        plot_h = 100        # было 130 — теперь 100
        gap = 22            # было 30 — теперь 22
        n = len(self.bits)
        bit_w = W / n

        methods = [
            ("NRZ",        encode_nrz,        WAVE_GREEN,   3),
            ("Манчестер",  encode_manchester, WAVE_CYAN,    3),
            ("MLT-3",      encode_mlt3,       WAVE_YELLOW,  3),
            ("AMI",        encode_ami,        WAVE_MAGENTA, 3),
            ("Импульсное", encode_pulse,      WAVE_ORANGE,  3),
        ]

        for idx, (name, func, color, width) in enumerate(methods):
            y_top = y_start + idx * (plot_h + gap)
            self._draw_plot(x0, y_top, W, plot_h, name,
                            func, color, width, bit_w, n)

        # Подписи бит внизу
        y_labels = y_start + len(methods) * (plot_h + gap) - gap + 14
        for i, b in enumerate(self.bits):
            x = x0 + i * bit_w + bit_w / 2
            self.canvas.create_text(
                x, y_labels,
                text=str(b),
                font=("Consolas", 10, "bold"),
                fill=TEXT,
            )

    def _draw_plot(self, x0, y_top, W, h, name,
                   encode_func, color, line_width, bit_w, n):
        c = self.canvas

        # Заголовок
        c.create_text(x0, y_top - 5,
                      text=name,
                      anchor="w",
                      font=("Segoe UI", 9, "bold"),
                      fill=TEXT)

        # Фон
        c.create_rectangle(x0, y_top, x0 + W, y_top + h,
                           fill=PLOT_BG, outline=PLOT_GRID, width=1)

        # Уровни Y
        if name in ("MLT-3", "AMI"):
            level_y = {
                1: y_top + h * 0.15,
                0: y_top + h * 0.5,
                -1: y_top + h * 0.85,
            }
        else:
            level_y = {
                1: y_top + h * 0.15,
                0: y_top + h * 0.85,
            }

        # Горизонтальная сетка
        for y in level_y.values():
            c.create_line(x0, y, x0 + W, y,
                          fill=PLOT_GRID, width=1)

        # Вертикальная сетка по границам бит
        for i in range(n + 1):
            x = x0 + i * bit_w
            c.create_line(x, y_top, x, y_top + h,
                          fill=PLOT_GRID, width=1)

        # Получаем последовательность
        points = encode_func(self.bits)

        # Рисуем ступенчатую линию
        x_cursor = x0
        prev_y = None

        for level, wf in points:
            y = level_y[level]
            seg_w = wf * bit_w

            if prev_y is None:
                c.create_line(x_cursor, y, x_cursor + seg_w, y,
                              fill=color, width=line_width)
            else:
                if prev_y != y:
                    c.create_line(x_cursor, prev_y, x_cursor, y,
                                  fill=color, width=line_width)
                c.create_line(x_cursor, y, x_cursor + seg_w, y,
                              fill=color, width=line_width)

            x_cursor += seg_w
            prev_y = y


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = EncodingApp(root)
    root.mainloop()
