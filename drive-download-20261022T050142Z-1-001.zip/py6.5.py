import tkinter as tk


# ─── Палитра ─────────────────────────────────────────────────────
BG = "#f7f7f9"
CARD = "#ffffff"
BORDER = "#e5e5ea"
TEXT = "#1c1c1e"
MUTED = "#8a8a8e"

ACCENT = "#0a84ff"          # синий — Unicode
ORANGE = "#ff9f0a"          # оранжевый — ASCII
GREEN = "#30d158"           # зелёный — CP1251
PURPLE = "#8e44ad"          # фиолетовый — CP866
RED = "#e53935"             # красный — не входит

HIGHLIGHT = "#fffbe6"       # жёлтая подсветка


# ═══════════════════════════════════════════════════════════════════
# КОДИРОВКИ
# ═══════════════════════════════════════════════════════════════════
def to_ascii(ch):
    """ASCII — только 0…127."""
    code = ord(ch)
    if 0 <= code <= 127:
        return code
    return None


def to_unicode(ch):
    """Unicode — код всегда есть."""
    return ord(ch)


def to_cp1251(ch):
    """Windows-1251 (кириллица Windows)."""
    try:
        return ch.encode("cp1251")[0]
    except (UnicodeEncodeError, IndexError):
        return None


def to_cp866(ch):
    """CP866 (кириллица DOS)."""
    try:
        return ch.encode("cp866")[0]
    except (UnicodeEncodeError, IndexError):
        return None


# ═══════════════════════════════════════════════════════════════════
# ПРИЛОЖЕНИЕ
# ═══════════════════════════════════════════════════════════════════
class KeyCodeApp:
    def __init__(self, root):
        self.root = root
        root.title("Коды символов клавиш")
        root.geometry("820x760")
        root.minsize(760, 720)
        root.configure(bg=BG)
        root.resizable(False, False)

        self.history = []      # последние нажатия
        self.last_char = None

        # ═══ Заголовок ═══════════════════════════════════════════
        tk.Label(root, text="Коды символов нажатых клавиш",
                 font=("Segoe UI", 16, "bold"),
                 bg=BG, fg=TEXT).pack(pady=(16, 3))

        tk.Label(root,
                 text="Нажмите любую клавишу — увидите код в 4 кодировках",
                 font=("Segoe UI", 9),
                 bg=BG, fg=MUTED).pack(pady=(0, 10))

        # ═══ Область для нажатия ═════════════════════════════════
        self.capture = tk.Frame(root, bg=CARD,
                                highlightthickness=2,
                                highlightbackground=ACCENT)
        self.capture.pack(padx=24, pady=(0, 10), fill="x")

        self.capture_label = tk.Label(
            self.capture, text="⌨  Нажмите клавишу здесь",
            font=("Segoe UI", 12),
            bg=CARD, fg=MUTED,
            padx=20, pady=22,
        )
        self.capture_label.pack()

        # Клик по области → фокус
        for w in (self.capture, self.capture_label):
            w.bind("<Button-1>", self.grab_focus)

        # Фокус для главного окна
        root.bind("<Key>", self.on_key)
        root.focus_set()

        # ═══ Крупный символ ══════════════════════════════════════
        symbol_card = tk.Frame(root, bg=CARD,
                               highlightthickness=1,
                               highlightbackground=BORDER)
        symbol_card.pack(padx=24, pady=(0, 10), fill="x")

        tk.Label(symbol_card, text="НАЖАТА КЛАВИША",
                 font=("Segoe UI", 8, "bold"),
                 bg=CARD, fg=MUTED).pack(pady=(10, 2))

        self.symbol_display = tk.Label(
            symbol_card, text="—",
            font=("Consolas", 44, "bold"),
            bg=CARD, fg=ACCENT, pady=4,
        )
        self.symbol_display.pack()

        self.key_name = tk.Label(
            symbol_card, text="",
            font=("Consolas", 10),
            bg=CARD, fg=MUTED, pady=(0, 10),
        )
        self.key_name.pack()

        # ═══ Таблица кодировок ═══════════════════════════════════
        table_card = tk.Frame(root, bg=CARD,
                              highlightthickness=1,
                              highlightbackground=BORDER)
        table_card.pack(padx=24, pady=(0, 10), fill="x")

        tk.Label(table_card, text="КОДИРОВКИ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED
                 ).pack(anchor="w", padx=18, pady=(12, 6))

        table = tk.Frame(table_card, bg=CARD)
        table.pack(fill="x", padx=18, pady=(0, 14))

        # Заголовки
        headers = ["Кодировка", "DEC", "HEX", "BIN", "Символ"]
        widths = [14, 7, 7, 12, 6]
        for col, (h, w) in enumerate(zip(headers, widths)):
            tk.Label(table, text=h,
                     font=("Segoe UI", 9, "bold"),
                     bg=CARD, fg=MUTED,
                     width=w, anchor="w"
                     ).grid(row=0, column=col, sticky="w", padx=(0, 8))

        # Строки кодировок
        self.rows = {}
        codings = [
            ("ASCII",   to_ascii,   ORANGE),
            ("Unicode", to_unicode, ACCENT),
            ("CP1251",  to_cp1251,  GREEN),
            ("CP866",   to_cp866,   PURPLE),
        ]

        for i, (name, func, color) in enumerate(codings, start=1):
            tk.Label(table, text=name,
                     font=("Segoe UI", 10, "bold"),
                     bg=CARD, fg=color,
                     width=14, anchor="w"
                     ).grid(row=i, column=0, sticky="w", padx=(0, 8), pady=4)

            dec = tk.Label(table, text="—",
                           font=("Consolas", 11, "bold"),
                           bg=CARD, fg=TEXT,
                           width=7, anchor="w")
            dec.grid(row=i, column=1, sticky="w", padx=(0, 8), pady=4)

            hexl = tk.Label(table, text="—",
                            font=("Consolas", 11),
                            bg=CARD, fg=MUTED,
                            width=7, anchor="w")
            hexl.grid(row=i, column=2, sticky="w", padx=(0, 8), pady=4)

            binl = tk.Label(table, text="—",
                            font=("Consolas", 10),
                            bg=CARD, fg=MUTED,
                            width=12, anchor="w")
            binl.grid(row=i, column=3, sticky="w", padx=(0, 8), pady=4)

            sym = tk.Label(table, text="",
                           font=("Segoe UI", 12, "bold"),
                           bg=CARD, fg=color,
                           width=6, anchor="w")
            sym.grid(row=i, column=4, sticky="w", pady=4)

            self.rows[name] = {
                "dec": dec, "hex": hexl, "bin": binl, "sym": sym,
                "func": func, "color": color,
            }

        # ═══ История ═════════════════════════════════════════════
        hist_card = tk.Frame(root, bg=CARD,
                             highlightthickness=1,
                             highlightbackground=BORDER)
        hist_card.pack(padx=24, pady=(0, 16), fill="both", expand=True)

        tk.Label(hist_card, text="ПОСЛЕДНИЕ НАЖАТИЯ",
                 font=("Segoe UI", 9, "bold"),
                 bg=CARD, fg=MUTED
                 ).pack(anchor="w", padx=18, pady=(12, 6))

        self.history_box = tk.Text(
            hist_card, height=5,
            font=("Consolas", 10),
            bg="#fafafa", fg=TEXT,
            bd=0, relief="flat",
            highlightthickness=0,
            padx=14, pady=10,
            state="disabled",
            wrap="word",
        )
        self.history_box.pack(fill="both", expand=True, padx=18, pady=(0, 14))

        # ═══ Статус ══════════════════════════════════════════════
        self.status = tk.Label(root, text="Ожидание нажатия клавиши…",
                               font=("Segoe UI", 9),
                               bg=BG, fg=MUTED)
        self.status.pack(side="bottom", pady=(0, 12))

    # ─── Фокус ─────────────────────────────────────────────────
    def grab_focus(self, event=None):
        self.root.focus_set()

    # ─── Обработка нажатия ─────────────────────────────────────
    def on_key(self, event):
        # Игнорируем модификаторы
        if event.keysym in ("Shift_L", "Shift_R", "Control_L", "Control_R",
                            "Alt_L", "Alt_R", "Caps_Lock", "Num_Lock"):
            return

        # Получаем символ
        char = event.char

        # Если символ пустой — это спецклавиша (Enter, Esc, F1, стрелки)
        if char == "" or char == "\x00":
            # Показываем имя клавиши, а не символ
            self._show_special_key(event)
            return

        # Обычный символ — обрабатываем
        self._show_char(char, event)

    def _show_char(self, char, event):
        """Показывает коды символа."""
        code_unicode = ord(char)

        # Обновляем крупный символ
        self.symbol_display.config(text=char, fg=ACCENT)
        self.key_name.config(
            text=f"keysym: {event.keysym}  ·  Unicode: U+{code_unicode:04X}"
        )

        # Обновляем таблицу кодировок
        for name, row in self.rows.items():
            value = row["func"](char)

            if value is None:
                # Символ не представим в этой кодировке
                row["dec"].config(text="не входит", fg=RED,
                                  font=("Segoe UI", 9))
                row["hex"].config(text="—", fg=MUTED)
                row["bin"].config(text="—", fg=MUTED)
                row["sym"].config(text="?", fg=RED)
            else:
                row["dec"].config(text=str(value), fg=TEXT,
                                  font=("Consolas", 11, "bold"))
                row["hex"].config(text=f"0x{value:02X}", fg=MUTED)
                row["bin"].config(text=f"{value:08b}", fg=MUTED)
                row["sym"].config(text=char, fg=row["color"])

        # Добавляем в историю
        self._add_history(char, code_unicode, event.keysym)

        self.status.config(
            text=f"Нажата клавиша '{char}'  ·  Unicode U+{code_unicode:04X}",
            fg=GREEN
        )

    def _show_special_key(self, event):
        """Показывает служебную клавишу."""
        name = event.keysym

        # Человекочитаемое имя
        friendly = {
            "Return":     "Enter ⏎",
            "Escape":     "Esc",
            "BackSpace":  "Backspace ⌫",
            "Tab":        "Tab ⇥",
            "space":      "Пробел",
            "Left":       "← Стрелка влево",
            "Right":      "→ Стрелка вправо",
            "Up":         "↑ Стрелка вверх",
            "Down":       "↓ Стрелка вниз",
            "Delete":     "Delete",
            "Home":       "Home",
            "End":        "End",
            "Prior":      "Page Up",
            "Next":       "Page Down",
        }.get(name, name)

        self.symbol_display.config(text="—", fg=MUTED)
        self.key_name.config(text=f"Служебная клавиша: {friendly}")

        # Очищаем таблицу
        for row in self.rows.values():
            row["dec"].config(text="—", fg=MUTED,
                              font=("Consolas", 11, "bold"))
            row["hex"].config(text="—", fg=MUTED)
            row["bin"].config(text="—", fg=MUTED)
            row["sym"].config(text="", fg=row["color"])

        self.status.config(
            text=f"Нажата служебная клавиша: {friendly}  ({name})",
            fg=ORANGE
        )

    # ─── История ───────────────────────────────────────────────
    def _add_history(self, char, code, keysym):
        # Собираем коды
        a = to_ascii(char)
        u = to_unicode(char)
        c1 = to_cp1251(char)
        c8 = to_cp866(char)

        def fmt(v):
            return f"{v:3d}" if v is not None else "  —"

        line = (f"'{char}'  key={keysym:<8}  "
                f"ASCII={fmt(a)}  "
                f"Uni={fmt(u)}  "
                f"CP1251={fmt(c1)}  "
                f"CP866={fmt(c8)}")

        self.history.append(line)
        if len(self.history) > 30:
            self.history = self.history[-30:]

        self.history_box.config(state="normal")
        self.history_box.delete("1.0", tk.END)
        for h in self.history:
            self.history_box.insert(tk.END, h + "\n")
        self.history_box.see(tk.END)
        self.history_box.config(state="disabled")


# ─── Запуск ──────────────────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    app = KeyCodeApp(root)
    root.mainloop()
